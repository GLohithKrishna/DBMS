package com.jobportal.controller;

import com.jobportal.dto.ApiResponse;
import com.jobportal.dto.JobDto;
import com.jobportal.entity.Job;
import com.jobportal.service.JobService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/jobs")
@RequiredArgsConstructor
@Tag(name = "Jobs", description = "Job listing, search, and management")
public class JobController {

    private final JobService jobService;

    // ── Public endpoints ──────────────────────────────────────────────────────

    @GetMapping
    @Operation(summary = "List all active jobs (paginated)")
    public ResponseEntity<ApiResponse<Page<JobDto.Summary>>> getAllJobs(
            @RequestParam(defaultValue = "0")  int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createdAt,desc") String sort) {

        Pageable pageable = buildPageable(page, size, sort);
        return ResponseEntity.ok(ApiResponse.success(jobService.getAllActiveJobs(pageable)));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get full job details by ID")
    public ResponseEntity<ApiResponse<JobDto.Response>> getJob(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(jobService.getJobById(id)));
    }

    @GetMapping("/search")
    @Operation(summary = "Keyword search across title, description, skills, company, location")
    public ResponseEntity<ApiResponse<Page<JobDto.Summary>>> search(
            @RequestParam String keyword,
            @RequestParam(defaultValue = "0")  int page,
            @RequestParam(defaultValue = "10") int size) {

        Pageable pageable = PageRequest.of(page, size);
        return ResponseEntity.ok(ApiResponse.success(
                jobService.searchJobs(keyword, pageable)));
    }

    @GetMapping("/filter")
    @Operation(summary = "Filter jobs by title, location, category, workMode, jobType, experienceLevel")
    public ResponseEntity<ApiResponse<Page<JobDto.Summary>>> filter(
            @RequestParam(required = false) String title,
            @RequestParam(required = false) String location,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) Job.WorkMode workMode,
            @RequestParam(required = false) Job.JobType jobType,
            @RequestParam(required = false) Job.ExperienceLevel experienceLevel,
            @RequestParam(defaultValue = "0")  int page,
            @RequestParam(defaultValue = "10") int size) {

        Pageable pageable = PageRequest.of(page, size);
        return ResponseEntity.ok(ApiResponse.success(
                jobService.filterJobs(title, location, category,
                        workMode, jobType, experienceLevel, pageable)));
    }

    @GetMapping("/categories")
    @Operation(summary = "List all available job categories")
    public ResponseEntity<ApiResponse<List<String>>> getCategories() {
        return ResponseEntity.ok(ApiResponse.success(jobService.getAllCategories()));
    }

    // ── Authenticated endpoints ───────────────────────────────────────────────

    @GetMapping("/discover")
    @Operation(summary = "Discover jobs matching the logged-in user's skills")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<Page<JobDto.Summary>>> discoverJobs(
            @AuthenticationPrincipal UserDetails userDetails,
            @RequestParam(defaultValue = "0")  int page,
            @RequestParam(defaultValue = "10") int size) {

        Pageable pageable = PageRequest.of(page, size);
        return ResponseEntity.ok(ApiResponse.success(
                jobService.discoverJobsByUserSkills(userDetails.getUsername(), pageable)));
    }

    @GetMapping("/my-postings")
    @Operation(summary = "Employer: list their own job postings")
    @PreAuthorize("hasAnyRole('EMPLOYER','ADMIN')")
    public ResponseEntity<ApiResponse<Page<JobDto.Summary>>> myPostings(
            @AuthenticationPrincipal UserDetails userDetails,
            @RequestParam(defaultValue = "0")  int page,
            @RequestParam(defaultValue = "10") int size) {

        Pageable pageable = PageRequest.of(page, size);
        return ResponseEntity.ok(ApiResponse.success(
                jobService.getJobsByEmployer(userDetails.getUsername(), pageable)));
    }

    @PostMapping
    @Operation(summary = "Employer: post a new job")
    @PreAuthorize("hasAnyRole('EMPLOYER','ADMIN')")
    public ResponseEntity<ApiResponse<JobDto.Response>> createJob(
            @Valid @RequestBody JobDto.CreateRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {

        JobDto.Response job = jobService.createJob(request, userDetails.getUsername());
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Job posted successfully.", job));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Employer: update a job posting")
    @PreAuthorize("hasAnyRole('EMPLOYER','ADMIN')")
    public ResponseEntity<ApiResponse<JobDto.Response>> updateJob(
            @PathVariable Long id,
            @RequestBody JobDto.UpdateRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {

        return ResponseEntity.ok(ApiResponse.success("Job updated.",
                jobService.updateJob(id, request, userDetails.getUsername())));
    }

    @PatchMapping("/{id}/close")
    @Operation(summary = "Employer: close a job posting")
    @PreAuthorize("hasAnyRole('EMPLOYER','ADMIN')")
    public ResponseEntity<ApiResponse<Void>> closeJob(
            @PathVariable Long id,
            @AuthenticationPrincipal UserDetails userDetails) {

        jobService.closeJob(id, userDetails.getUsername());
        return ResponseEntity.ok(ApiResponse.success("Job closed.", null));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Employer/Admin: delete a job posting")
    @PreAuthorize("hasAnyRole('EMPLOYER','ADMIN')")
    public ResponseEntity<ApiResponse<Void>> deleteJob(
            @PathVariable Long id,
            @AuthenticationPrincipal UserDetails userDetails) {

        jobService.deleteJob(id, userDetails.getUsername());
        return ResponseEntity.ok(ApiResponse.success("Job deleted.", null));
    }

    // ── Utility ──────────────────────────────────────────────────────────────

    private Pageable buildPageable(int page, int size, String sort) {
        String[] parts = sort.split(",");
        Sort.Direction dir = parts.length > 1 && parts[1].equalsIgnoreCase("asc")
                ? Sort.Direction.ASC : Sort.Direction.DESC;
        return PageRequest.of(page, size, Sort.by(dir, parts[0]));
    }
}
