# Job Portal Backend — Spring Boot REST API

A complete backend for a **Job Listing & Application** system built with
Spring Boot 3.2, Spring Security (JWT), Spring Data JPA, and H2/MySQL.

---

## Tech Stack

| Layer        | Technology                                  |
|--------------|---------------------------------------------|
| Framework    | Spring Boot 3.2.5                           |
| Security     | Spring Security + JWT (JJWT 0.11.5)        |
| Persistence  | Spring Data JPA + Hibernate                 |
| Database     | H2 (dev/test) · MySQL (production)          |
| Docs         | SpringDoc OpenAPI 2 (Swagger UI)            |
| Build        | Maven 3 · Java 17                           |

---

## Quick Start (Spring Tool Suite / IntelliJ)

```bash
# 1. Import as Maven project
# 2. Run com.jobportal.JobPortalApplication

# H2 Console  →  http://localhost:8080/api/h2-console
# Swagger UI  →  http://localhost:8080/api/swagger-ui.html
# Base URL    →  http://localhost:8080/api
```

### Switch to MySQL (production)
Edit `src/main/resources/application.properties`:
```properties
# Comment the H2 block, uncomment MySQL block
spring.datasource.url=jdbc:mysql://localhost:3306/job_portal?...
spring.datasource.username=root
spring.datasource.password=yourpassword
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.MySQLDialect
spring.jpa.hibernate.ddl-auto=update
```

---

## Demo Credentials (auto-seeded on first run)

| Role      | Username      | Password       |
|-----------|---------------|----------------|
| Admin     | `admin`       | `Admin@123`    |
| Employer  | `techcorp`    | `Employer@123` |
| Employer  | `cloudinc`    | `Employer@123` |
| Applicant | `rajesh_dev`  | `User@123`     |
| Applicant | `priya_cloud` | `User@123`     |

---

## API Endpoints

### Authentication  `/api/auth`
| Method | Path              | Description                   | Auth |
|--------|-------------------|-------------------------------|------|
| POST   | `/auth/register`  | Register (APPLICANT/EMPLOYER) | ✗    |
| POST   | `/auth/login`     | Login → JWT token             | ✗    |

### Jobs  `/api/jobs`
| Method | Path                   | Description                          | Role           |
|--------|------------------------|--------------------------------------|----------------|
| GET    | `/jobs`                | List active jobs (paginated)         | Public         |
| GET    | `/jobs/{id}`           | Job details                          | Public         |
| GET    | `/jobs/search?keyword=`| Keyword search                       | Public         |
| GET    | `/jobs/filter`         | Multi-field filter                   | Public         |
| GET    | `/jobs/categories`     | All categories                       | Public         |
| GET    | `/jobs/discover`       | Skill-matched jobs for current user  | Authenticated  |
| GET    | `/jobs/my-postings`    | Employer's own postings              | EMPLOYER/ADMIN |
| POST   | `/jobs`                | Post a new job                       | EMPLOYER/ADMIN |
| PUT    | `/jobs/{id}`           | Update job                           | EMPLOYER/ADMIN |
| PATCH  | `/jobs/{id}/close`     | Close job                            | EMPLOYER/ADMIN |
| DELETE | `/jobs/{id}`           | Delete job                           | EMPLOYER/ADMIN |

#### Filter Query Params
```
/jobs/filter?title=java&location=hyderabad&category=IT
             &workMode=REMOTE&jobType=FULL_TIME&experienceLevel=FRESHER
             &page=0&size=10
```

### Applications  `/api/applications`
| Method | Path                         | Description                         | Role           |
|--------|------------------------------|-------------------------------------|----------------|
| POST   | `/applications/jobs/{jobId}` | Submit application                  | APPLICANT      |
| GET    | `/applications/my`           | My applications                     | APPLICANT      |
| GET    | `/applications/my/summary`   | Status counts                       | APPLICANT      |
| GET    | `/applications/{id}`         | Single application                  | Owner/Employer |
| GET    | `/applications/jobs/{jobId}` | All applications for a job          | EMPLOYER/ADMIN |
| PATCH  | `/applications/{id}/status`  | Update status (shortlist/reject...) | EMPLOYER/ADMIN |
| PATCH  | `/applications/{id}/withdraw`| Withdraw application                | APPLICANT      |

#### Application Status Flow
```
APPLIED → UNDER_REVIEW → SHORTLISTED → INTERVIEW_SCHEDULED
       → INTERVIEW_COMPLETED → OFFER_EXTENDED → HIRED
       → REJECTED / WITHDRAWN (at any stage)
```

### User Profile  `/api/users`
| Method | Path               | Description                   | Auth          |
|--------|--------------------|-------------------------------|---------------|
| GET    | `/users/me`        | Get my profile                | Authenticated |
| PUT    | `/users/me`        | Update profile (skills, bio…) | Authenticated |
| PATCH  | `/users/me/password` | Change password             | Authenticated |

---

## Request / Response Examples

### Register
```json
POST /api/auth/register
{
  "username": "john_doe",
  "email": "john@example.com",
  "password": "Secret@123",
  "firstName": "John",
  "lastName": "Doe",
  "role": "APPLICANT"
}
```

### Login
```json
POST /api/auth/login
{ "identifier": "john_doe", "password": "Secret@123" }

Response:
{ "success": true, "data": { "token": "eyJ...", "role": "APPLICANT" } }
```

### Post a Job (employer)
```json
POST /api/jobs
Authorization: Bearer <token>
{
  "title": "Software Developer – Fresher",
  "company": "StartupXYZ",
  "location": "Hyderabad",
  "jobType": "FULL_TIME",
  "workMode": "HYBRID",
  "experienceLevel": "FRESHER",
  "description": "Join our growing product team...",
  "skillsRequired": "Java, Spring Boot, MySQL",
  "salaryMin": 400000,
  "salaryMax": 600000,
  "currency": "INR",
  "category": "IT",
  "openings": 3
}
```

### Apply for a Job
```json
POST /api/applications/jobs/1
Authorization: Bearer <applicant-token>
{
  "coverLetter": "I am excited to apply for this position..."
}
```

### Update Application Status (employer)
```json
PATCH /api/applications/5/status
Authorization: Bearer <employer-token>
{
  "status": "INTERVIEW_SCHEDULED",
  "interviewDate": "2025-07-15T10:00:00",
  "employerNotes": "Strong Java fundamentals, shortlisted."
}
```

---

## Project Structure
```
src/main/java/com/jobportal/
├── JobPortalApplication.java
├── config/
│   ├── CustomUserDetailsService.java
│   ├── DataSeeder.java          ← demo data
│   ├── JwtAuthFilter.java
│   ├── JwtUtils.java
│   ├── SecurityConfig.java
│   └── SwaggerConfig.java
├── controller/
│   ├── AuthController.java
│   ├── ApplicationController.java
│   ├── JobController.java
│   └── UserController.java
├── dto/
│   ├── ApiResponse.java
│   ├── AuthDto.java
│   ├── ApplicationDto.java
│   ├── JobDto.java
│   └── UserDto.java
├── entity/
│   ├── Application.java
│   ├── Job.java
│   └── User.java
├── exception/
│   ├── BadRequestException.java
│   ├── ForbiddenException.java
│   ├── GlobalExceptionHandler.java
│   └── ResourceNotFoundException.java
├── repository/
│   ├── ApplicationRepository.java
│   ├── JobRepository.java
│   └── UserRepository.java
└── service/
    ├── AuthService.java
    ├── ApplicationService.java
    ├── JobService.java
    ├── UserService.java
    └── impl/
        ├── AuthServiceImpl.java
        ├── ApplicationServiceImpl.java
        ├── JobServiceImpl.java
        └── UserServiceImpl.java
```

---

## SQL Table Schema (auto-generated by Hibernate)

### users
```sql
id, username, email, password, first_name, last_name,
phone, skills, bio, resume_url, role, enabled,
created_at, updated_at
```

### jobs
```sql
id, title, company, location, job_type, work_mode,
experience_level, description, requirements, responsibilities,
skills_required, salary_min, salary_max, currency,
deadline, status, category, openings, posted_by (FK→users),
created_at, updated_at
```

### applications
```sql
id, job_id (FK→jobs), applicant_id (FK→users),
cover_letter, resume_url, status, employer_notes,
rejection_reason, interview_date, applied_at, updated_at
UNIQUE (job_id, applicant_id)
```
