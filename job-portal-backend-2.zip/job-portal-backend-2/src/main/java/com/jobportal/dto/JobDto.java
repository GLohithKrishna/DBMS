package com.jobportal.dto;

import com.jobportal.entity.Job;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class JobDto {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class CreateRequest {
        @NotBlank
        private String title;

        @NotBlank
        private String company;

        private String location;

        @NotNull
        private Job.JobType jobType;

        private Job.WorkMode workMode;

        @NotNull
        private Job.ExperienceLevel experienceLevel;

        @NotBlank
        private String description;

        private String requirements;
        private String responsibilities;
        private String skillsRequired;

        private BigDecimal salaryMin;
        private BigDecimal salaryMax;
        private String currency;

        private LocalDate deadline;
        private String category;
        private Integer openings;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class UpdateRequest {
        private String title;
        private String company;
        private String location;
        private Job.JobType jobType;
        private Job.WorkMode workMode;
        private Job.ExperienceLevel experienceLevel;
        private String description;
        private String requirements;
        private String responsibilities;
        private String skillsRequired;
        private BigDecimal salaryMin;
        private BigDecimal salaryMax;
        private String currency;
        private LocalDate deadline;
        private String category;
        private Integer openings;
        private Job.JobStatus status;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Response {
        private Long id;
        private String title;
        private String company;
        private String location;
        private Job.JobType jobType;
        private Job.WorkMode workMode;
        private Job.ExperienceLevel experienceLevel;
        private String description;
        private String requirements;
        private String responsibilities;
        private String skillsRequired;
        private BigDecimal salaryMin;
        private BigDecimal salaryMax;
        private String currency;
        private LocalDate deadline;
        private Job.JobStatus status;
        private String category;
        private Integer openings;
        private Long postedById;
        private String postedByUsername;
        private long totalApplications;
        private LocalDateTime createdAt;
        private LocalDateTime updatedAt;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Summary {
        private Long id;
        private String title;
        private String company;
        private String location;
        private Job.JobType jobType;
        private Job.WorkMode workMode;
        private Job.ExperienceLevel experienceLevel;
        private String category;
        private BigDecimal salaryMin;
        private BigDecimal salaryMax;
        private String currency;
        private Job.JobStatus status;
        private LocalDateTime createdAt;
    }
}
