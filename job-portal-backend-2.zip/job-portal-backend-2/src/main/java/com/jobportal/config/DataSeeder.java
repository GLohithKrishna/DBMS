package com.jobportal.config;

import com.jobportal.entity.Application;
import com.jobportal.entity.Job;
import com.jobportal.entity.User;
import com.jobportal.repository.ApplicationRepository;
import com.jobportal.repository.JobRepository;
import com.jobportal.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.Profile;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;

@Slf4j
@Profile("!test")
@Component
@RequiredArgsConstructor
public class DataSeeder implements CommandLineRunner {

    private final UserRepository userRepo;
    private final JobRepository jobRepo;
    private final ApplicationRepository appRepo;
    private final PasswordEncoder encoder;

    @Override
    public void run(String... args) {
        if (userRepo.count() > 0) return; // already seeded

        log.info("Seeding demo data...");

        // ── Users ──────────────────────────────────────────────────────────────
        User admin = userRepo.save(User.builder()
                .username("admin")
                .email("admin@jobportal.com")
                .password(encoder.encode("Admin@123"))
                .firstName("Super").lastName("Admin")
                .role(User.Role.ADMIN).enabled(true).build());

        User employer1 = userRepo.save(User.builder()
                .username("techcorp")
                .email("hr@techcorp.com")
                .password(encoder.encode("Employer@123"))
                .firstName("TechCorp").lastName("HR")
                .role(User.Role.EMPLOYER).enabled(true).build());

        User employer2 = userRepo.save(User.builder()
                .username("cloudinc")
                .email("hr@cloudinc.com")
                .password(encoder.encode("Employer@123"))
                .firstName("CloudInc").lastName("HR")
                .role(User.Role.EMPLOYER).enabled(true).build());

        User applicant1 = userRepo.save(User.builder()
                .username("rajesh_dev")
                .email("rajesh@gmail.com")
                .password(encoder.encode("User@123"))
                .firstName("Rajesh").lastName("Kumar")
                .skills("Java, Spring Boot, MySQL, REST API")
                .role(User.Role.APPLICANT).enabled(true).build());

        User applicant2 = userRepo.save(User.builder()
                .username("priya_cloud")
                .email("priya@gmail.com")
                .password(encoder.encode("User@123"))
                .firstName("Priya").lastName("Sharma")
                .skills("AWS, Terraform, Docker, Kubernetes")
                .role(User.Role.APPLICANT).enabled(true).build());

        // ── Jobs ──────────────────────────────────────────────────────────────
        Job j1 = jobRepo.save(Job.builder()
                .title("Java Backend Developer - Fresher")
                .company("TechCorp Solutions")
                .location("Hyderabad, Telangana")
                .jobType(Job.JobType.FULL_TIME)
                .workMode(Job.WorkMode.HYBRID)
                .experienceLevel(Job.ExperienceLevel.FRESHER)
                .description("We are looking for a passionate Java developer to join our backend team. "
                        + "You will work on building scalable REST APIs and microservices.")
                .requirements("B.Tech/MCA in CS or related field. Good knowledge of Java and OOP.")
                .skillsRequired("Java, Spring Boot, MySQL, REST API")
                .salaryMin(new BigDecimal("400000"))
                .salaryMax(new BigDecimal("600000"))
                .currency("INR")
                .deadline(LocalDate.now().plusDays(30))
                .category("IT")
                .openings(5)
                .status(Job.JobStatus.ACTIVE)
                .postedBy(employer1)
                .build());

        Job j2 = jobRepo.save(Job.builder()
                .title("Cloud Engineer - Remote")
                .company("CloudInc Technologies")
                .location("Remote")
                .jobType(Job.JobType.FULL_TIME)
                .workMode(Job.WorkMode.REMOTE)
                .experienceLevel(Job.ExperienceLevel.MID)
                .description("Join our cloud-native team to design and operate infrastructure at scale. "
                        + "You will own cloud deployments, CI/CD pipelines, and reliability.")
                .requirements("2+ years cloud experience. AWS certifications preferred.")
                .skillsRequired("AWS, Terraform, Docker, Kubernetes, CI/CD")
                .salaryMin(new BigDecimal("1000000"))
                .salaryMax(new BigDecimal("1500000"))
                .currency("INR")
                .deadline(LocalDate.now().plusDays(45))
                .category("Cloud")
                .openings(3)
                .status(Job.JobStatus.ACTIVE)
                .postedBy(employer2)
                .build());

        jobRepo.save(Job.builder()
                .title("React Frontend Developer")
                .company("TechCorp Solutions")
                .location("Bangalore, Karnataka")
                .jobType(Job.JobType.FULL_TIME)
                .workMode(Job.WorkMode.ONSITE)
                .experienceLevel(Job.ExperienceLevel.JUNIOR)
                .description("Build modern, responsive web applications using React and TypeScript.")
                .skillsRequired("React, TypeScript, HTML, CSS, REST API")
                .salaryMin(new BigDecimal("600000"))
                .salaryMax(new BigDecimal("900000"))
                .currency("INR")
                .deadline(LocalDate.now().plusDays(20))
                .category("IT")
                .openings(2)
                .status(Job.JobStatus.ACTIVE)
                .postedBy(employer1)
                .build());

        jobRepo.save(Job.builder()
                .title("Data Science Intern")
                .company("CloudInc Technologies")
                .location("Remote")
                .jobType(Job.JobType.INTERNSHIP)
                .workMode(Job.WorkMode.REMOTE)
                .experienceLevel(Job.ExperienceLevel.FRESHER)
                .description("6-month paid internship in our data science team. Learn ML pipelines.")
                .skillsRequired("Python, Pandas, Scikit-learn, SQL")
                .salaryMin(new BigDecimal("15000"))
                .salaryMax(new BigDecimal("20000"))
                .currency("INR")
                .deadline(LocalDate.now().plusDays(15))
                .category("Data Science")
                .openings(10)
                .status(Job.JobStatus.ACTIVE)
                .postedBy(employer2)
                .build());

        // ── Applications ──────────────────────────────────────────────────────
        appRepo.save(Application.builder()
                .job(j1).applicant(applicant1)
                .coverLetter("I am a passionate Java developer eager to join your team.")
                .status(Application.ApplicationStatus.UNDER_REVIEW)
                .build());

        appRepo.save(Application.builder()
                .job(j2).applicant(applicant2)
                .coverLetter("Cloud is my passion! I have hands-on experience with AWS and Kubernetes.")
                .status(Application.ApplicationStatus.SHORTLISTED)
                .build());

        log.info("Demo data seeded. Users: admin/Admin@123, techcorp/Employer@123, "
               + "rajesh_dev/User@123, priya_cloud/User@123");
    }
}
