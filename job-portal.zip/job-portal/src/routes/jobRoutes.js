// src/routes/jobRoutes.js
const express = require('express');
const router  = express.Router();
const ctrl    = require('../controllers/jobsController');
const { authenticate, authorize } = require('../middleware/auth');

// Public
router.get('/',              ctrl.getAllJobs);
router.get('/employer/my',   authenticate, authorize('employer', 'admin'), ctrl.getMyJobs);
router.get('/:id',           ctrl.getJobById);

// Protected
router.post('/',             authenticate, authorize('employer', 'admin'), ctrl.createJob);
router.put('/:id',           authenticate, authorize('employer', 'admin'), ctrl.updateJob);
router.delete('/:id',        authenticate, authorize('employer', 'admin'), ctrl.deleteJob);

module.exports = router;
