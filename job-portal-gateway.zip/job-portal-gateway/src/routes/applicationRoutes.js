const express = require('express');
const pool = require('../config/db');
const { getDB } = require('../config/mongo');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();

// ------------------------------------------------------------
// POST /api/applications
// Submit an application for a job
// Body: { job_id, cover_letter, resume_url }
// ------------------------------------------------------------
router.post('/', authMiddleware, async (req, res) => {
  try {
    const { job_id, cover_letter, resume_url } = req.body;
    if (!job_id) return res.status(400).json({ error: 'job_id is required' });

    // Ensure job exists and is open
    const jobResult = await pool.query('SELECT * FROM jobs WHERE job_id = $1', [job_id]);
    if (jobResult.rows.length === 0) return res.status(404).json({ error: 'Job not found' });
    if (jobResult.rows[0].status !== 'open') {
      return res.status(400).json({ error: 'This job is no longer accepting applications' });
    }

    // Prevent duplicate applications
    const existing = await pool.query(
      'SELECT application_id FROM applications WHERE job_id = $1 AND user_id = $2',
      [job_id, req.user.user_id]
    );
    if (existing.rows.length > 0) {
      return res.status(409).json({ error: 'You have already applied to this job' });
    }

    const result = await pool.query(
      `INSERT INTO applications (job_id, user_id, cover_letter, resume_url, status)
       VALUES ($1, $2, $3, $4, 'submitted')
       RETURNING *`,
      [job_id, req.user.user_id, cover_letter || null, resume_url || null]
    );

    const application = result.rows[0];

    // Log application event in MongoDB
    const db = getDB();
    await db.collection('application_logs').insertOne({
      application_id: application.application_id,
      job_id: application.job_id,
      user_id: application.user_id,
      event: 'submitted',
      status: 'submitted',
      timestamp: new Date(),
    });

    res.status(201).json(application);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to submit application' });
  }
});

// ------------------------------------------------------------
// GET /api/applications/my
// Track all of the logged-in user's applications (status tracking)
// ------------------------------------------------------------
router.get('/my', authMiddleware, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT a.*, j.title, j.company, j.location, j.job_type
       FROM applications a
       JOIN jobs j ON a.job_id = j.job_id
       WHERE a.user_id = $1
       ORDER BY a.applied_at DESC`,
      [req.user.user_id]
    );
    res.json({ count: result.rows.length, applications: result.rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch applications' });
  }
});

// ------------------------------------------------------------
// GET /api/applications/job/:jobId
// Recruiter view: all applications for a specific job
// ------------------------------------------------------------
router.get('/job/:jobId', authMiddleware, async (req, res) => {
  try {
    if (req.user.role !== 'recruiter' && req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Only recruiters can view job applications' });
    }

    const { jobId } = req.params;
    const result = await pool.query(
      `SELECT a.*, u.name, u.email, u.skills
       FROM applications a
       JOIN users u ON a.user_id = u.user_id
       WHERE a.job_id = $1
       ORDER BY a.applied_at DESC`,
      [jobId]
    );
    res.json({ count: result.rows.length, applications: result.rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch applications' });
  }
});

// ------------------------------------------------------------
// PATCH /api/applications/:id/status
// Update application status (recruiter only)
// Body: { status: 'shortlisted' | 'interview' | 'rejected' | 'hired' | 'under_review' }
// ------------------------------------------------------------
router.patch('/:id/status', authMiddleware, async (req, res) => {
  try {
    if (req.user.role !== 'recruiter' && req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Only recruiters can update application status' });
    }

    const { id } = req.params;
    const { status } = req.body;
    const validStatuses = ['submitted', 'under_review', 'shortlisted', 'interview', 'rejected', 'hired'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ error: `status must be one of: ${validStatuses.join(', ')}` });
    }

    const result = await pool.query(
      `UPDATE applications SET status = $1, updated_at = NOW() WHERE application_id = $2 RETURNING *`,
      [status, id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Application not found' });

    const application = result.rows[0];

    const db = getDB();
    await db.collection('application_logs').insertOne({
      application_id: application.application_id,
      job_id: application.job_id,
      user_id: application.user_id,
      event: 'status_updated',
      status,
      timestamp: new Date(),
    });

    res.json(application);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to update application status' });
  }
});

// ------------------------------------------------------------
// GET /api/applications/:id/history
// Get the full status history/log of an application (MongoDB)
// ------------------------------------------------------------
router.get('/:id/history', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    const db = getDB();
    const logs = await db
      .collection('application_logs')
      .find({ application_id: parseInt(id, 10) })
      .sort({ timestamp: 1 })
      .toArray();
    res.json({ application_id: parseInt(id, 10), history: logs });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch application history' });
  }
});

module.exports = router;
