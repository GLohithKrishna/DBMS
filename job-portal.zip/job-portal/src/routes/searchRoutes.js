// src/routes/searchRoutes.js
const express = require('express');
const router  = express.Router();
const ctrl    = require('../controllers/searchController');
const { authenticate } = require('../middleware/auth');

// POST /api/search/semantic  — vector semantic search
router.post('/semantic',         ctrl.semanticSearch);

// GET  /api/search/keyword?q=  — PostgreSQL full-text fallback
router.get('/keyword',           ctrl.keywordFallback);

// GET  /api/search/recommendations  — skill-matched jobs (auth required)
router.get('/recommendations',   authenticate, ctrl.getRecommendations);

module.exports = router;
