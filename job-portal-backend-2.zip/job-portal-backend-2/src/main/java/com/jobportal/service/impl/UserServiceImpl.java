package com.jobportal.service.impl;

import com.jobportal.dto.UserDto;
import com.jobportal.entity.User;
import com.jobportal.exception.BadRequestException;
import com.jobportal.exception.ResourceNotFoundException;
import com.jobportal.repository.UserRepository;
import com.jobportal.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    @Transactional(readOnly = true)
    public UserDto.Response getProfile(String username) {
        return toResponse(getUser(username));
    }

    @Override
    @Transactional
    public UserDto.Response updateProfile(String username, UserDto.UpdateRequest req) {
        User user = getUser(username);
        if (req.getFirstName() != null) user.setFirstName(req.getFirstName());
        if (req.getLastName()  != null) user.setLastName(req.getLastName());
        if (req.getPhone()     != null) user.setPhone(req.getPhone());
        if (req.getSkills()    != null) user.setSkills(req.getSkills());
        if (req.getBio()       != null) user.setBio(req.getBio());
        if (req.getResumeUrl() != null) user.setResumeUrl(req.getResumeUrl());
        return toResponse(userRepository.save(user));
    }

    @Override
    @Transactional
    public void changePassword(String username, UserDto.ChangePasswordRequest req) {
        User user = getUser(username);
        if (!passwordEncoder.matches(req.getCurrentPassword(), user.getPassword())) {
            throw new BadRequestException("Current password is incorrect.");
        }
        user.setPassword(passwordEncoder.encode(req.getNewPassword()));
        userRepository.save(user);
    }

    private User getUser(String username) {
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + username));
    }

    private UserDto.Response toResponse(User u) {
        return UserDto.Response.builder()
                .id(u.getId())
                .username(u.getUsername())
                .email(u.getEmail())
                .firstName(u.getFirstName())
                .lastName(u.getLastName())
                .phone(u.getPhone())
                .skills(u.getSkills())
                .bio(u.getBio())
                .resumeUrl(u.getResumeUrl())
                .role(u.getRole())
                .enabled(u.isEnabled())
                .createdAt(u.getCreatedAt())
                .build();
    }
}
