// src/server.js
// ============================================================
// Job Portal API Server — PS-13
// ============================================================

require('dotenv').config();
const express      = require('express');
const cors         = require('cors');
const morgan       = require('morgan');
const connectMongo = require('./config/mongodb');

const app = express();

// ── Middleware ────────────────────────────────────────────────
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(morgan('dev'));

// ── Connect MongoDB ───────────────────────────────────────────
connectMongo();

// ── Routes ────────────────────────────────────────────────────
app.use('/api/auth',         require('./routes/authRoutes'));
app.use('/api/jobs',         require('./routes/jobRoutes'));
app.use('/api/applications', require('./routes/applicationRoutes'));
app.use('/api/search',       require('./routes/searchRoutes'));

// ── Health check ─────────────────────────────────────────────
app.get('/api/health', (req, res) =>
  res.json({ status: 'ok', timestamp: new Date().toISOString() })
);

// ── 404 handler ───────────────────────────────────────────────
app.use((req, res) =>
  res.status(404).json({ success: false, message: `Route ${req.originalUrl} not found` })
);

// ── Global error handler ──────────────────────────────────────
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err.stack);
  res.status(500).json({ success: false, message: 'Internal server error' });
});

// ── Start ─────────────────────────────────────────────────────
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`\n🚀 Job Portal API running on http://localhost:${PORT}`);
  console.log(`   ENV: ${process.env.NODE_ENV || 'development'}`);
  console.log(`   Endpoints:`);
  console.log(`     POST /api/auth/register`);
  console.log(`     POST /api/auth/login`);
  console.log(`     GET  /api/jobs`);
  console.log(`     POST /api/jobs`);
  console.log(`     POST /api/applications`);
  console.log(`     POST /api/search/semantic`);
  console.log(`     GET  /api/search/keyword?q=`);
});

module.exports = app;
