package com.jobportal.service;

import com.jobportal.dto.UserDto;

public interface UserService {
    UserDto.Response getProfile(String username);
    UserDto.Response updateProfile(String username, UserDto.UpdateRequest request);
    void changePassword(String username, UserDto.ChangePasswordRequest request);
}
