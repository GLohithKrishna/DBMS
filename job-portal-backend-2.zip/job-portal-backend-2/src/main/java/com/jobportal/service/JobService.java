package com.jobportal.service;

import com.jobportal.dto.JobDto;
import com.jobportal.entity.Job;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface JobService {

    JobDto.Response createJob(JobDto.CreateRequest request, String username);

    JobDto.Response getJobById(Long id);

    Page<JobDto.Summary> getAllActiveJobs(Pageable pageable);

    Page<JobDto.Summary> searchJobs(String keyword, Pageable pageable);

    Page<JobDto.Summary> filterJobs(String title,
                                    String location,
                                    String category,
                                    Job.WorkMode workMode,
                                    Job.JobType jobType,
                                    Job.ExperienceLevel experienceLevel,
                                    Pageable pageable);

    Page<JobDto.Summary> discoverJobsByUserSkills(String username, Pageable pageable);

    Page<JobDto.Summary> getJobsByEmployer(String username, Pageable pageable);

    JobDto.Response updateJob(Long id, JobDto.UpdateRequest request, String username);

    void deleteJob(Long id, String username);

    void closeJob(Long id, String username);

    List<String> getAllCategories();
}
