// src/routes/applicationRoutes.js
const express = require('express');
const router  = express.Router();
const ctrl    = require('../controllers/applicationsController');
const { authenticate, authorize } = require('../middleware/auth');

router.post('/',                    authenticate, authorize('jobseeker'),           ctrl.applyForJob);
router.get('/my',                   authenticate, authorize('jobseeker'),           ctrl.getMyApplications);
router.get('/job/:job_id',          authenticate, authorize('employer', 'admin'),   ctrl.getJobApplications);
router.patch('/:id/status',         authenticate, authorize('employer', 'admin'),   ctrl.updateApplicationStatus);
router.get('/:id/history',          authenticate,                                   ctrl.getApplicationHistory);

module.exports = router;
