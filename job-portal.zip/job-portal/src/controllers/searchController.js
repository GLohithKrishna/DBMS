// src/controllers/searchController.js
// Semantic (vector) search using MongoDB Atlas + OpenAI embeddings

const { JobEmbedding, JobDescription } = require('../models/mongoModels');
const pool = require('../config/postgres');

// ────────────────────────────────────────────────────────────────────────────
// Helper: generate embedding via OpenAI
// Falls back to keyword search if API key is missing
// ────────────────────────────────────────────────────────────────────────────
const getEmbedding = async (text) => {
  if (!process.env.OPENAI_API_KEY) return null;

  const OpenAI = require('openai');
  const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

  const response = await openai.embeddings.create({
    model: 'text-embedding-ada-002',
    input: text,
  });
  return response.data[0].embedding;
};

// ── POST /api/search/semantic ─────────────────────────────────────────────────
// Body: { query: "Software developer jobs for freshers" }
// Uses MongoDB Atlas $vectorSearch (requires Atlas M10+ or local Atlas CLI)
exports.semanticSearch = async (req, res) => {
  try {
    const { query, limit = 10 } = req.body;
    if (!query)
      return res.status(400).json({ success: false, message: 'query is required' });

    // 1. Get embedding for the query
    const queryEmbedding = await getEmbedding(query);

    if (!queryEmbedding) {
      // Fallback: keyword search in PostgreSQL
      return exports.keywordFallback(req, res);
    }

    // 2. Run MongoDB Atlas $vectorSearch
    const results = await JobEmbedding.aggregate([
      {
        $vectorSearch: {
          index:       'job_vector_index',   // Atlas search index name
          path:        'embedding',
          queryVector: queryEmbedding,
          numCandidates: 100,
          limit:         Number(limit),
        },
      },
      {
        $project: {
          postgres_job_id:  1,
          title:            1,
          skills:           1,
          experience_level: 1,
          job_type:         1,
          score:            { $meta: 'vectorSearchScore' },
        },
      },
    ]);

    if (!results.length)
      return res.json({ success: true, results: [], message: 'No matching jobs found' });

    // 3. Fetch full job details from PostgreSQL
    const jobIds    = results.map(r => r.postgres_job_id);
    const pgResult  = await pool.query(
      `SELECT j.*, u.name AS employer_name
       FROM jobs j JOIN users u ON u.id = j.employer_id
       WHERE j.id = ANY($1) AND j.is_active = TRUE`,
      [jobIds]
    );

    // 4. Merge scores with PG data
    const pgMap = Object.fromEntries(pgResult.rows.map(j => [j.id, j]));
    const merged = results
      .filter(r => pgMap[r.postgres_job_id])
      .map(r => ({ ...pgMap[r.postgres_job_id], similarity_score: r.score }));

    res.json({ success: true, query, results: merged });
  } catch (err) {
    console.error('Semantic search error:', err.message);
    res.status(500).json({ success: false, message: err.message });
  }
};

// ── GET /api/search/keyword?q=...  (PostgreSQL full-text fallback) ────────────
exports.keywordFallback = async (req, res) => {
  try {
    const query = req.body?.query || req.query?.q || '';
    const limit = req.query?.limit || 10;

    const { rows } = await pool.query(
      `SELECT j.*, u.name AS employer_name,
              ts_rank(to_tsvector('english', j.title || ' ' || COALESCE(j.location,'') || ' ' ||
                                             array_to_string(j.required_skills,' ')),
                      plainto_tsquery('english', $1)) AS rank
       FROM jobs j
       JOIN users u ON u.id = j.employer_id
       WHERE j.is_active = TRUE
         AND to_tsvector('english', j.title || ' ' || COALESCE(j.location,'') || ' ' ||
                                    array_to_string(j.required_skills,' '))
             @@ plainto_tsquery('english', $1)
       ORDER BY rank DESC
       LIMIT $2`,
      [query, Number(limit)]
    );

    res.json({ success: true, query, results: rows, source: 'keyword_fallback' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// ── POST /api/search/index-job  (index a job for vector search) ──────────────
exports.indexJobEmbedding = async (jobId) => {
  try {
    const pgResult = await pool.query(
      'SELECT * FROM jobs WHERE id = $1', [jobId]
    );
    if (!pgResult.rows.length) return;

    const job = pgResult.rows[0];
    const text = [
      job.title,
      job.company,
      job.location,
      job.job_type,
      job.experience_level,
      (job.required_skills || []).join(' '),
    ].join('. ');

    const embedding = await getEmbedding(text);
    if (!embedding) return;

    await JobEmbedding.findOneAndUpdate(
      { postgres_job_id: jobId },
      {
        postgres_job_id:  jobId,
        title:            job.title,
        embedding_text:   text,
        embedding,
        skills:           job.required_skills || [],
        experience_level: job.experience_level,
        job_type:         job.job_type,
      },
      { upsert: true, new: true }
    );
    console.log(`✅ Indexed job ${jobId} for vector search`);
  } catch (err) {
    console.error(`Failed to index job ${jobId}:`, err.message);
  }
};

// ── GET /api/search/recommendations  (jobs matching user skills) ──────────────
exports.getRecommendations = async (req, res) => {
  try {
    const userResult = await pool.query('SELECT skills FROM users WHERE id = $1', [req.user.id]);
    const skills = userResult.rows[0]?.skills;

    if (!skills || !skills.length)
      return res.json({ success: true, results: [], message: 'Add skills to your profile for recommendations' });

    const { rows } = await pool.query(
      `SELECT j.*, u.name AS employer_name,
              cardinality(j.required_skills & $1::text[]) AS matching_skills
       FROM jobs j
       JOIN users u ON u.id = j.employer_id
       WHERE j.is_active = TRUE
         AND j.required_skills && $1::text[]
       ORDER BY matching_skills DESC
       LIMIT 10`,
      [skills]
    );

    res.json({ success: true, based_on_skills: skills, results: rows });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};
