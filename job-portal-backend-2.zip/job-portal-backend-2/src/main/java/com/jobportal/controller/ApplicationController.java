package com.jobportal.controller;

import com.jobportal.dto.ApiResponse;
import com.jobportal.dto.ApplicationDto;
import com.jobportal.service.ApplicationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/applications")
@RequiredArgsConstructor
@Tag(name = "Applications", description = "Job application submission and tracking")
public class ApplicationController {

    private final ApplicationService applicationService;

    @PostMapping("/jobs/{jobId}")
    @Operation(summary = "Applicant: submit application for a job")
    @PreAuthorize("hasRole('APPLICANT')")
    public ResponseEntity<ApiResponse<ApplicationDto.Response>> apply(
            @PathVariable Long jobId,
            @RequestBody ApplicationDto.SubmitRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {

        ApplicationDto.Response response =
                applicationService.applyForJob(jobId, request, userDetails.getUsername());
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Application submitted successfully.", response));
    }

    @GetMapping("/my")
    @Operation(summary = "Applicant: view all my applications")
    @PreAuthorize("hasRole('APPLICANT')")
    public ResponseEntity<ApiResponse<Page<ApplicationDto.Response>>> myApplications(
            @AuthenticationPrincipal UserDetails userDetails,
            @RequestParam(defaultValue = "0")  int page,
            @RequestParam(defaultValue = "10") int size) {

        Pageable pageable = PageRequest.of(page, size);
        return ResponseEntity.ok(ApiResponse.success(
                applicationService.getMyApplications(userDetails.getUsername(), pageable)));
    }

    @GetMapping("/my/summary")
    @Operation(summary = "Applicant: view application status counts")
    @PreAuthorize("hasRole('APPLICANT')")
    public ResponseEntity<ApiResponse<ApplicationDto.StatusSummary>> myStatusSummary(
            @AuthenticationPrincipal UserDetails userDetails) {

        return ResponseEntity.ok(ApiResponse.success(
                applicationService.getStatusSummary(userDetails.getUsername())));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get a single application by ID (applicant or employer)")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<ApplicationDto.Response>> getApplication(
            @PathVariable Long id,
            @AuthenticationPrincipal UserDetails userDetails) {

        return ResponseEntity.ok(ApiResponse.success(
                applicationService.getApplicationById(id, userDetails.getUsername())));
    }

    @GetMapping("/jobs/{jobId}")
    @Operation(summary = "Employer: view all applications for a job (optional ?status= filter)")
    @PreAuthorize("hasAnyRole('EMPLOYER','ADMIN')")
    public ResponseEntity<ApiResponse<Page<ApplicationDto.Response>>> jobApplications(
            @PathVariable Long jobId,
            @RequestParam(required = false) String status,
            @AuthenticationPrincipal UserDetails userDetails,
            @RequestParam(defaultValue = "0")  int page,
            @RequestParam(defaultValue = "10") int size) {

        Pageable pageable = PageRequest.of(page, size);
        return ResponseEntity.ok(ApiResponse.success(
                applicationService.getApplicationsForJob(
                        jobId, status, userDetails.getUsername(), pageable)));
    }

    @PatchMapping("/{id}/status")
    @Operation(summary = "Employer: update application status (shortlist, reject, schedule interview...)")
    @PreAuthorize("hasAnyRole('EMPLOYER','ADMIN')")
    public ResponseEntity<ApiResponse<ApplicationDto.Response>> updateStatus(
            @PathVariable Long id,
            @RequestBody ApplicationDto.StatusUpdateRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {

        return ResponseEntity.ok(ApiResponse.success("Status updated.",
                applicationService.updateApplicationStatus(
                        id, request, userDetails.getUsername())));
    }

    @PatchMapping("/{id}/withdraw")
    @Operation(summary = "Applicant: withdraw an application")
    @PreAuthorize("hasRole('APPLICANT')")
    public ResponseEntity<ApiResponse<Void>> withdraw(
            @PathVariable Long id,
            @AuthenticationPrincipal UserDetails userDetails) {

        applicationService.withdrawApplication(id, userDetails.getUsername());
        return ResponseEntity.ok(ApiResponse.success("Application withdrawn.", null));
    }
}
