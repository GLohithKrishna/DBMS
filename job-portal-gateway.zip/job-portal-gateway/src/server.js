const express = require('express');
const cors = require('cors');
require('dotenv').config();

const { connectMongo } = require('./config/mongo');
const pool = require('./config/db');

const authRoutes = require('./routes/authRoutes');
const jobRoutes = require('./routes/jobRoutes');
const applicationRoutes = require('./routes/applicationRoutes');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// ------------------------------------------------------------
// Health check
// ------------------------------------------------------------
app.get('/api/health', async (req, res) => {
  const health = { status: 'ok', sql: 'unknown', mongo: 'unknown' };

  try {
    await pool.query('SELECT 1');
    health.sql = 'connected';
  } catch (err) {
    health.sql = `error: ${err.message}`;
  }

  try {
    const { getDB } = require('./config/mongo');
    await getDB().command({ ping: 1 });
    health.mongo = 'connected';
  } catch (err) {
    health.mongo = `error: ${err.message}`;
  }

  res.json(health);
});

// ------------------------------------------------------------
// API Routes (Gateway)
// ------------------------------------------------------------
app.use('/api/auth', authRoutes);
app.use('/api/jobs', jobRoutes);
app.use('/api/applications', applicationRoutes);

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// Global error handler
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Internal server error' });
});

// ------------------------------------------------------------
// Start server
// ------------------------------------------------------------
async function start() {
  try {
    await connectMongo();
  } catch (err) {
    console.error('Failed to connect to MongoDB:', err.message);
    console.error('Server will continue, but Mongo-based features (semantic search, logs) will fail until fixed.');
  }

  app.listen(PORT, () => {
    console.log(`Job Portal backend gateway running on http://localhost:${PORT}`);
  });
}

start();
