// mongodb-setup/seed-mongo.js
// Run: node mongodb-setup/seed-mongo.js
// Seeds: job_descriptions, application_logs (and stubs for job_embeddings)

require('dotenv').config({ path: '../.env' });
const mongoose = require('mongoose');
const { JobDescription, JobEmbedding, ApplicationLog } = require('../src/models/mongoModels');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/job_portal';

const jobDescriptions = [
  {
    postgres_job_id: 1,
    title: 'Full Stack Developer',
    company: 'TechHire Inc',
    full_description: `We are looking for a passionate Full Stack Developer to join our growing team.
You will be responsible for developing and maintaining web applications using Node.js and React.
This is an excellent opportunity for freshers with strong fundamentals.`,
    responsibilities: [
      'Build and maintain RESTful APIs using Node.js/Express',
      'Develop responsive UI components using React',
      'Design and optimize PostgreSQL and MongoDB schemas',
      'Write unit and integration tests',
      'Collaborate with cross-functional teams',
    ],
    requirements: [
      '0-2 years of experience (freshers welcome)',
      'Proficiency in JavaScript, Node.js, React',
      'Basic understanding of SQL and NoSQL databases',
      'Familiarity with Git',
    ],
    benefits: ['Health insurance', 'Work from home 2 days/week', 'Annual learning budget ₹20,000'],
    tech_stack: ['Node.js', 'React', 'PostgreSQL', 'MongoDB', 'Docker'],
    tags: ['fresher-friendly', 'hybrid', 'startup'],
    employment_details: { job_type: 'full-time', experience_level: 'entry', work_mode: 'hybrid' },
    company_details: {
      industry: 'Technology',
      size: '50-200',
      website: 'https://techhire.example.com',
      about: 'TechHire Inc is a product startup building HR-tech solutions.',
    },
    application_stats: { total_applications: 2, views: 45 },
  },
  {
    postgres_job_id: 2,
    title: 'Backend Engineer',
    company: 'TechHire Inc',
    full_description: `Join our backend team to build scalable microservices.
You will own critical API infrastructure and mentor junior developers.`,
    responsibilities: [
      'Design and build high-performance RESTful APIs',
      'Optimize database queries and indexing strategies',
      'Implement authentication and authorization systems',
      'Participate in architecture reviews',
    ],
    requirements: [
      '2-4 years of backend development experience',
      'Expert-level Node.js and Express',
      'Strong MongoDB and PostgreSQL knowledge',
      'Experience with Redis and message queues',
    ],
    benefits: ['Equity options', 'Remote-friendly', 'Top-tier health cover'],
    tech_stack: ['Node.js', 'MongoDB', 'PostgreSQL', 'Redis', 'RabbitMQ'],
    tags: ['mid-level', 'microservices', 'remote-friendly'],
    employment_details: { job_type: 'full-time', experience_level: 'mid', work_mode: 'hybrid' },
    company_details: { industry: 'Technology', size: '50-200', website: 'https://techhire.example.com', about: 'TechHire Inc' },
    application_stats: { total_applications: 1, views: 30 },
  },
  {
    postgres_job_id: 3,
    title: 'Cloud Infrastructure Engineer',
    company: 'CloudCo',
    full_description: `CloudCo is hiring a senior cloud engineer to design and maintain our AWS infrastructure.
You will lead the migration of legacy services to Kubernetes and implement IaC with Terraform.`,
    responsibilities: [
      'Design and manage AWS infrastructure (EKS, RDS, S3, CloudFront)',
      'Write Terraform modules for infrastructure as code',
      'Implement CI/CD pipelines using GitHub Actions',
      'Monitor and optimize cloud costs',
      'Lead incident response and post-mortems',
    ],
    requirements: [
      '5+ years of cloud engineering experience',
      'AWS Solutions Architect certification preferred',
      'Expert Terraform and Kubernetes knowledge',
      'Strong scripting (Python/Bash)',
    ],
    benefits: ['100% remote', 'Stock options', 'Conference budget $3,000/year'],
    tech_stack: ['AWS', 'Terraform', 'Kubernetes', 'Docker', 'Python', 'GitHub Actions'],
    tags: ['remote', 'senior', 'cloud', 'aws'],
    employment_details: { job_type: 'remote', experience_level: 'senior', work_mode: 'remote' },
    company_details: {
      industry: 'Cloud Services',
      size: '200-1000',
      website: 'https://cloudco.example.com',
      about: 'CloudCo provides managed cloud infrastructure for enterprise clients.',
    },
    application_stats: { total_applications: 1, views: 120 },
  },
  {
    postgres_job_id: 4,
    title: 'DevOps Intern',
    company: 'CloudCo',
    full_description: `An exciting internship opportunity for students or fresh graduates interested in DevOps and cloud engineering.
You will work alongside senior engineers and get hands-on experience with real production systems.`,
    responsibilities: [
      'Assist in writing Dockerfiles and Compose configurations',
      'Monitor CI/CD pipeline health',
      'Document infrastructure and runbooks',
      'Shadow on-call rotations',
    ],
    requirements: [
      'Currently enrolled in CS/IT degree or recent graduate',
      'Basic Linux command line knowledge',
      'Familiarity with Git',
      'Eagerness to learn',
    ],
    benefits: ['Stipend ₹12,000/month', 'PPO opportunity', 'Mentorship from senior engineers'],
    tech_stack: ['Linux', 'Docker', 'Git', 'CI/CD', 'Bash'],
    tags: ['internship', 'remote', 'fresher', 'devops'],
    employment_details: { job_type: 'internship', experience_level: 'entry', work_mode: 'remote' },
    company_details: { industry: 'Cloud Services', size: '200-1000', website: 'https://cloudco.example.com', about: 'CloudCo' },
    application_stats: { total_applications: 1, views: 80 },
  },
  {
    postgres_job_id: 5,
    title: 'React Frontend Developer',
    company: 'TechHire Inc',
    full_description: `We need a creative frontend developer who loves building polished user interfaces.
You will own the customer-facing dashboard and work closely with our design team.`,
    responsibilities: [
      'Build pixel-perfect React components from Figma designs',
      'Manage state with Redux Toolkit or Zustand',
      'Integrate REST and GraphQL APIs',
      'Write Storybook stories and unit tests with Jest + RTL',
    ],
    requirements: [
      '1-3 years of React development experience',
      'Proficiency in TypeScript and modern CSS',
      'Experience with component libraries (MUI, Tailwind)',
      'Understanding of web performance optimization',
    ],
    benefits: ['Flexible hours', 'Learning stipend', 'MacBook Pro provided'],
    tech_stack: ['React', 'TypeScript', 'Redux', 'Tailwind CSS', 'Jest'],
    tags: ['frontend', 'react', 'hybrid', 'junior'],
    employment_details: { job_type: 'full-time', experience_level: 'entry', work_mode: 'hybrid' },
    company_details: { industry: 'Technology', size: '50-200', website: 'https://techhire.example.com', about: 'TechHire Inc' },
    application_stats: { total_applications: 1, views: 60 },
  },
];

const applicationLogs = [
  {
    postgres_application_id: 1,
    postgres_job_id:   1,
    postgres_user_id:  2,
    applicant_name:    'Bob Dev',
    job_title:         'Full Stack Developer',
    company:           'TechHire Inc',
    events: [
      { status: 'pending',   changed_by: 2, changed_at: new Date('2025-01-10'), note: 'Application submitted' },
    ],
    metadata: { ip_address: '10.0.0.1', source: 'web' },
  },
  {
    postgres_application_id: 2,
    postgres_job_id:   2,
    postgres_user_id:  2,
    applicant_name:    'Bob Dev',
    job_title:         'Backend Engineer',
    company:           'TechHire Inc',
    events: [
      { status: 'pending',     changed_by: 2, changed_at: new Date('2025-01-12'), note: 'Application submitted' },
      { status: 'reviewed',    changed_by: 1, changed_at: new Date('2025-01-14'), note: 'Strong profile' },
      { status: 'shortlisted', changed_by: 1, changed_at: new Date('2025-01-15'), note: 'Proceed to technical round' },
    ],
    metadata: { ip_address: '10.0.0.1', source: 'web' },
  },
  {
    postgres_application_id: 3,
    postgres_job_id:   3,
    postgres_user_id:  3,
    applicant_name:    'Carol Engineer',
    job_title:         'Cloud Infrastructure Engineer',
    company:           'CloudCo',
    events: [
      { status: 'pending',  changed_by: 3, changed_at: new Date('2025-01-08'), note: 'Application submitted' },
      { status: 'reviewed', changed_by: 4, changed_at: new Date('2025-01-10'), note: 'Good AWS experience' },
    ],
    metadata: { ip_address: '10.0.0.2', source: 'web' },
  },
  {
    postgres_application_id: 4,
    postgres_job_id:   4,
    postgres_user_id:  3,
    applicant_name:    'Carol Engineer',
    job_title:         'DevOps Intern',
    company:           'CloudCo',
    events: [
      { status: 'pending',  changed_by: 3, changed_at: new Date('2025-01-09'), note: 'Application submitted' },
      { status: 'rejected', changed_by: 4, changed_at: new Date('2025-01-11'), note: 'Overqualified for internship role' },
    ],
    metadata: { ip_address: '10.0.0.2', source: 'mobile' },
  },
  {
    postgres_application_id: 5,
    postgres_job_id:   5,
    postgres_user_id:  2,
    applicant_name:    'Bob Dev',
    job_title:         'React Frontend Developer',
    company:           'TechHire Inc',
    events: [
      { status: 'pending', changed_by: 2, changed_at: new Date('2025-01-13'), note: 'Application submitted' },
    ],
    metadata: { ip_address: '10.0.0.1', source: 'web' },
  },
];

// Stub embeddings (replace with real OpenAI vectors in production)
const jobEmbeddingStubs = jobDescriptions.map(jd => ({
  postgres_job_id:  jd.postgres_job_id,
  title:            jd.title,
  embedding_text:   `${jd.title} ${jd.company} ${jd.tech_stack.join(' ')} ${jd.employment_details.experience_level}`,
  embedding:        Array.from({ length: 1536 }, () => Math.random() * 2 - 1), // STUB — replace with real embeddings
  model:            'text-embedding-ada-002',
  skills:           jd.tech_stack,
  experience_level: jd.employment_details.experience_level,
  job_type:         jd.employment_details.job_type,
}));

async function seed() {
  try {
    console.log('🔌 Connecting to MongoDB...');
    await mongoose.connect(MONGO_URI);
    console.log('✅ Connected');

    // Clear existing
    await JobDescription.deleteMany({});
    await JobEmbedding.deleteMany({});
    await ApplicationLog.deleteMany({});
    console.log('🗑️  Cleared existing collections');

    // Insert
    await JobDescription.insertMany(jobDescriptions);
    console.log(`✅ Inserted ${jobDescriptions.length} job descriptions`);

    await JobEmbedding.insertMany(jobEmbeddingStubs);
    console.log(`✅ Inserted ${jobEmbeddingStubs.length} job embedding stubs`);

    await ApplicationLog.insertMany(applicationLogs);
    console.log(`✅ Inserted ${applicationLogs.length} application logs`);

    console.log('\n✅ MongoDB seed complete!');
    console.log('📝 NOTE: job_embeddings contain stub vectors.');
    console.log('   Set OPENAI_API_KEY and run /api/search/index-job to generate real embeddings.');
    process.exit(0);
  } catch (err) {
    console.error('❌ Seed error:', err.message);
    process.exit(1);
  }
}

seed();
