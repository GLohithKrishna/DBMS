// src/models/mongoModels.js
// MongoDB Collections: job_descriptions, job_embeddings, application_logs

const mongoose = require('mongoose');

// ============================================================
// Collection: job_descriptions
// Stores full rich job descriptions (NoSQL flexible schema)
// ============================================================
const jobDescriptionSchema = new mongoose.Schema(
  {
    postgres_job_id: { type: Number, required: true, unique: true, index: true },
    title:           { type: String, required: true },
    company:         { type: String, required: true },
    full_description: { type: String, required: true },
    responsibilities: [String],
    requirements:    [String],
    benefits:        [String],
    tech_stack:      [String],
    tags:            [String],           // e.g. ['remote', 'fresher-friendly', 'startup']
    employment_details: {
      job_type:        String,
      experience_level: String,
      work_mode:       { type: String, enum: ['remote', 'hybrid', 'onsite'] },
      notice_period:   String,
    },
    company_details: {
      industry:   String,
      size:       String,
      website:    String,
      about:      String,
    },
    application_stats: {
      total_applications: { type: Number, default: 0 },
      views:              { type: Number, default: 0 },
    },
  },
  { timestamps: true, collection: 'job_descriptions' }
);

// ============================================================
// Collection: job_embeddings
// Stores vector embeddings for semantic search
// ============================================================
const jobEmbeddingSchema = new mongoose.Schema(
  {
    postgres_job_id:  { type: Number, required: true, unique: true, index: true },
    title:            { type: String, required: true },
    embedding_text:   { type: String, required: true },  // Text used to generate embedding
    embedding:        { type: [Number], required: true }, // 1536-dim OpenAI vector
    model:            { type: String, default: 'text-embedding-ada-002' },
    skills:           [String],
    experience_level: String,
    job_type:         String,
  },
  { timestamps: true, collection: 'job_embeddings' }
);

// Vector search index (MongoDB Atlas $vectorSearch)
// Run once in Atlas UI or via Atlas Admin API:
// {
//   "mappings": {
//     "fields": {
//       "embedding": [{ "type": "knnVector", "dimensions": 1536, "similarity": "cosine" }]
//     }
//   }
// }

// ============================================================
// Collection: application_logs
// Full audit trail of application status changes
// ============================================================
const applicationLogSchema = new mongoose.Schema(
  {
    postgres_application_id: { type: Number, required: true, index: true },
    postgres_job_id:         { type: Number, required: true, index: true },
    postgres_user_id:        { type: Number, required: true, index: true },
    applicant_name:          String,
    job_title:               String,
    company:                 String,
    events: [
      {
        status:    { type: String, enum: ['pending', 'reviewed', 'shortlisted', 'rejected', 'hired'] },
        changed_by: Number,   // user_id who changed the status
        changed_at: { type: Date, default: Date.now },
        note:       String,
      },
    ],
    metadata: {
      ip_address:  String,
      user_agent:  String,
      source:      { type: String, default: 'web' },
    },
  },
  { timestamps: true, collection: 'application_logs' }
);

const JobDescription  = mongoose.model('JobDescription',  jobDescriptionSchema);
const JobEmbedding    = mongoose.model('JobEmbedding',    jobEmbeddingSchema);
const ApplicationLog  = mongoose.model('ApplicationLog',  applicationLogSchema);

module.exports = { JobDescription, JobEmbedding, ApplicationLog };
