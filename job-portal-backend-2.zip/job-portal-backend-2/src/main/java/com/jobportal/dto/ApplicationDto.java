package com.jobportal.dto;

import com.jobportal.entity.Application;
import lombok.*;

import java.time.LocalDateTime;
import java.util.Map;

public class ApplicationDto {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class SubmitRequest {
        private String coverLetter;
        private String resumeUrl;   // optional override
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class StatusUpdateRequest {
        private Application.ApplicationStatus status;
        private String employerNotes;
        private String rejectionReason;
        private LocalDateTime interviewDate;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Response {
        private Long id;
        private Long jobId;
        private String jobTitle;
        private String company;
        private Long applicantId;
        private String applicantUsername;
        private String applicantEmail;
        private String coverLetter;
        private String resumeUrl;
        private Application.ApplicationStatus status;
        private String employerNotes;
        private String rejectionReason;
        private LocalDateTime interviewDate;
        private LocalDateTime appliedAt;
        private LocalDateTime updatedAt;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class StatusSummary {
        private Map<String, Long> statusCounts;
        private long totalApplications;
    }
}
