package com.jobportal.service.impl;

import com.jobportal.dto.ApplicationDto;
import com.jobportal.entity.Application;
import com.jobportal.entity.Job;
import com.jobportal.entity.User;
import com.jobportal.exception.BadRequestException;
import com.jobportal.exception.ForbiddenException;
import com.jobportal.exception.ResourceNotFoundException;
import com.jobportal.repository.ApplicationRepository;
import com.jobportal.repository.JobRepository;
import com.jobportal.repository.UserRepository;
import com.jobportal.service.ApplicationService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class ApplicationServiceImpl implements ApplicationService {

    private final ApplicationRepository applicationRepository;
    private final JobRepository jobRepository;
    private final UserRepository userRepository;

    @Override
    @Transactional
    public ApplicationDto.Response applyForJob(Long jobId,
                                               ApplicationDto.SubmitRequest request,
                                               String username) {
        User applicant = getUser(username);
        Job job = getJob(jobId);

        if (job.getStatus() != Job.JobStatus.ACTIVE) {
            throw new BadRequestException("This job is no longer accepting applications.");
        }
        if (applicationRepository.existsByJobIdAndApplicantId(jobId, applicant.getId())) {
            throw new BadRequestException("You have already applied for this job.");
        }

        String resumeUrl = (request.getResumeUrl() != null)
                ? request.getResumeUrl()
                : applicant.getResumeUrl();

        Application app = Application.builder()
                .job(job)
                .applicant(applicant)
                .coverLetter(request.getCoverLetter())
                .resumeUrl(resumeUrl)
                .status(Application.ApplicationStatus.APPLIED)
                .build();

        return toResponse(applicationRepository.save(app));
    }

    @Override
    @Transactional(readOnly = true)
    public Page<ApplicationDto.Response> getMyApplications(String username, Pageable pageable) {
        User user = getUser(username);
        return applicationRepository.findByApplicantId(user.getId(), pageable)
                .map(this::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public ApplicationDto.Response getApplicationById(Long id, String username) {
        Application app = getApp(id);
        User caller = getUser(username);
        assertCanViewApp(app, caller);
        return toResponse(app);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<ApplicationDto.Response> getApplicationsForJob(Long jobId,
                                                               String status,
                                                               String username,
                                                               Pageable pageable) {
        Job job = getJob(jobId);
        User caller = getUser(username);

        boolean isOwner = job.getPostedBy().getId().equals(caller.getId());
        boolean isAdmin  = caller.getRole() == User.Role.ADMIN;
        if (!isOwner && !isAdmin) {
            throw new ForbiddenException("You are not authorized to view these applications.");
        }

        if (status != null) {
            Application.ApplicationStatus appStatus =
                    Application.ApplicationStatus.valueOf(status.toUpperCase());
            return applicationRepository.findByJobIdAndStatus(jobId, appStatus, pageable)
                    .map(this::toResponse);
        }
        return applicationRepository.findByJobId(jobId, pageable).map(this::toResponse);
    }

    @Override
    @Transactional
    public ApplicationDto.Response updateApplicationStatus(Long id,
                                                           ApplicationDto.StatusUpdateRequest req,
                                                           String username) {
        Application app = getApp(id);
        User caller = getUser(username);

        boolean isOwner = app.getJob().getPostedBy().getId().equals(caller.getId());
        boolean isAdmin  = caller.getRole() == User.Role.ADMIN;
        if (!isOwner && !isAdmin) {
            throw new ForbiddenException("You are not authorized to update this application.");
        }

        if (req.getStatus() != null)          app.setStatus(req.getStatus());
        if (req.getEmployerNotes() != null)   app.setEmployerNotes(req.getEmployerNotes());
        if (req.getRejectionReason() != null) app.setRejectionReason(req.getRejectionReason());
        if (req.getInterviewDate() != null)   app.setInterviewDate(req.getInterviewDate());

        return toResponse(applicationRepository.save(app));
    }

    @Override
    @Transactional
    public void withdrawApplication(Long id, String username) {
        Application app = getApp(id);
        User caller = getUser(username);

        if (!app.getApplicant().getId().equals(caller.getId())) {
            throw new ForbiddenException("You can only withdraw your own application.");
        }
        if (app.getStatus() == Application.ApplicationStatus.HIRED) {
            throw new BadRequestException("Cannot withdraw an accepted offer.");
        }

        app.setStatus(Application.ApplicationStatus.WITHDRAWN);
        applicationRepository.save(app);
    }

    @Override
    @Transactional(readOnly = true)
    public ApplicationDto.StatusSummary getStatusSummary(String username) {
        User user = getUser(username);
        List<Object[]> rows = applicationRepository.countByStatusForApplicant(user.getId());

        Map<String, Long> counts = new LinkedHashMap<>();
        long total = 0;
        for (Object[] row : rows) {
            String status = ((Application.ApplicationStatus) row[0]).name();
            long count = (Long) row[1];
            counts.put(status, count);
            total += count;
        }
        return new ApplicationDto.StatusSummary(counts, total);
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private Application getApp(Long id) {
        return applicationRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Application not found with id: " + id));
    }

    private Job getJob(Long id) {
        return jobRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Job not found with id: " + id));
    }

    private User getUser(String username) {
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "User not found: " + username));
    }

    private void assertCanViewApp(Application app, User caller) {
        boolean isApplicant = app.getApplicant().getId().equals(caller.getId());
        boolean isEmployer  = app.getJob().getPostedBy().getId().equals(caller.getId());
        boolean isAdmin     = caller.getRole() == User.Role.ADMIN;
        if (!isApplicant && !isEmployer && !isAdmin) {
            throw new ForbiddenException("Access denied.");
        }
    }

    private ApplicationDto.Response toResponse(Application a) {
        return ApplicationDto.Response.builder()
                .id(a.getId())
                .jobId(a.getJob().getId())
                .jobTitle(a.getJob().getTitle())
                .company(a.getJob().getCompany())
                .applicantId(a.getApplicant().getId())
                .applicantUsername(a.getApplicant().getUsername())
                .applicantEmail(a.getApplicant().getEmail())
                .coverLetter(a.getCoverLetter())
                .resumeUrl(a.getResumeUrl())
                .status(a.getStatus())
                .employerNotes(a.getEmployerNotes())
                .rejectionReason(a.getRejectionReason())
                .interviewDate(a.getInterviewDate())
                .appliedAt(a.getAppliedAt())
                .updatedAt(a.getUpdatedAt())
                .build();
    }
}
