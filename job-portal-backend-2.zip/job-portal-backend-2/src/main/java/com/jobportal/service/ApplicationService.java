package com.jobportal.service;

import com.jobportal.dto.ApplicationDto;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface ApplicationService {

    ApplicationDto.Response applyForJob(Long jobId,
                                        ApplicationDto.SubmitRequest request,
                                        String username);

    Page<ApplicationDto.Response> getMyApplications(String username, Pageable pageable);

    ApplicationDto.Response getApplicationById(Long id, String username);

    Page<ApplicationDto.Response> getApplicationsForJob(Long jobId,
                                                        String status,
                                                        String username,
                                                        Pageable pageable);

    ApplicationDto.Response updateApplicationStatus(Long id,
                                                    ApplicationDto.StatusUpdateRequest request,
                                                    String username);

    void withdrawApplication(Long id, String username);

    ApplicationDto.StatusSummary getStatusSummary(String username);
}
