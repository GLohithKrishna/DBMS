const { MongoClient } = require('mongodb');
require('dotenv').config();

const uri = process.env.MONGO_URI || 'mongodb://localhost:27017';
const dbName = process.env.MONGO_DB || 'job_portal';

let client;
let db;

async function connectMongo() {
  if (db) return db;
  client = new MongoClient(uri);
  await client.connect();
  db = client.db(dbName);
  console.log(`Connected to MongoDB database: ${dbName}`);
  return db;
}

function getDB() {
  if (!db) {
    throw new Error('MongoDB not connected yet. Call connectMongo() first.');
  }
  return db;
}

module.exports = { connectMongo, getDB };
