// src/controllers/jobsController.js
const pool             = require('../config/postgres');
const { JobDescription, JobEmbedding } = require('../models/mongoModels');

// ── GET /api/jobs  (list + filter + search) ──────────────────────────────────
exports.getAllJobs = async (req, res) => {
  try {
    const {
      keyword, location, job_type, experience_level,
      min_salary, max_salary, skills,
      page = 1, limit = 10, sort = 'newest',
    } = req.query;

    const params = [];
    let idx = 1;

    let sql = `
      SELECT j.*, u.name AS employer_name, u.email AS employer_email,
             COUNT(a.id) AS application_count
      FROM   jobs j
      JOIN   users u ON u.id = j.employer_id
      LEFT JOIN applications a ON a.job_id = j.id
      WHERE  j.is_active = TRUE
    `;

    if (keyword) {
      sql += ` AND (j.title ILIKE $${idx} OR j.company ILIKE $${idx})`;
      params.push(`%${keyword}%`);
      idx++;
    }
    if (location) {
      sql += ` AND j.location ILIKE $${idx}`;
      params.push(`%${location}%`);
      idx++;
    }
    if (job_type) {
      sql += ` AND j.job_type = $${idx}`;
      params.push(job_type);
      idx++;
    }
    if (experience_level) {
      sql += ` AND j.experience_level = $${idx}`;
      params.push(experience_level);
      idx++;
    }
    if (min_salary) {
      sql += ` AND j.salary_min >= $${idx}`;
      params.push(Number(min_salary));
      idx++;
    }
    if (max_salary) {
      sql += ` AND j.salary_max <= $${idx}`;
      params.push(Number(max_salary));
      idx++;
    }
    if (skills) {
      const skillArr = skills.split(',').map(s => s.trim());
      sql += ` AND j.required_skills && $${idx}::text[]`;
      params.push(skillArr);
      idx++;
    }

    sql += ' GROUP BY j.id, u.name, u.email';
    sql += sort === 'oldest' ? ' ORDER BY j.created_at ASC' : ' ORDER BY j.created_at DESC';

    const offset = (Number(page) - 1) * Number(limit);
    sql += ` LIMIT $${idx} OFFSET $${idx + 1}`;
    params.push(Number(limit), offset);

    const { rows } = await pool.query(sql, params);

    // Count total for pagination
    let countSql = `SELECT COUNT(*) FROM jobs j WHERE j.is_active = TRUE`;
    const countResult = await pool.query(countSql);
    const total = parseInt(countResult.rows[0].count);

    res.json({
      success: true,
      total,
      page: Number(page),
      pages: Math.ceil(total / Number(limit)),
      jobs: rows,
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// ── GET /api/jobs/:id ─────────────────────────────────────────────────────────
exports.getJobById = async (req, res) => {
  try {
    const { id } = req.params;

    // Get SQL data
    const result = await pool.query(
      `SELECT j.*, u.name AS employer_name, u.email AS employer_email,
              COUNT(a.id) AS application_count
       FROM   jobs j
       JOIN   users u ON u.id = j.employer_id
       LEFT JOIN applications a ON a.job_id = j.id
       WHERE  j.id = $1
       GROUP BY j.id, u.name, u.email`,
      [id]
    );
    if (!result.rows.length)
      return res.status(404).json({ success: false, message: 'Job not found' });

    // Increment view count in MongoDB
    const [job, description] = await Promise.all([
      result.rows[0],
      JobDescription.findOneAndUpdate(
        { postgres_job_id: Number(id) },
        { $inc: { 'application_stats.views': 1 } },
        { new: true }
      ),
    ]);

    res.json({ success: true, job: { ...job, description } });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// ── POST /api/jobs  (employer only) ──────────────────────────────────────────
exports.createJob = async (req, res) => {
  try {
    const {
      title, company, location, job_type = 'full-time',
      salary_min, salary_max, experience_level = 'entry',
      required_skills = [], deadline,
      // MongoDB fields
      full_description, responsibilities, requirements, benefits,
      tech_stack, tags, work_mode, company_details,
    } = req.body;

    if (!title || !company)
      return res.status(400).json({ success: false, message: 'title and company are required' });

    // Insert into PostgreSQL
    const pgResult = await pool.query(
      `INSERT INTO jobs
         (employer_id, title, company, location, job_type, salary_min, salary_max,
          experience_level, required_skills, deadline)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
       RETURNING *`,
      [req.user.id, title, company, location, job_type, salary_min || null,
       salary_max || null, experience_level, required_skills, deadline || null]
    );
    const job = pgResult.rows[0];

    // Insert rich description into MongoDB
    if (full_description) {
      await JobDescription.create({
        postgres_job_id:    job.id,
        title,
        company,
        full_description,
        responsibilities:   responsibilities   || [],
        requirements:       requirements       || [],
        benefits:           benefits           || [],
        tech_stack:         tech_stack         || required_skills,
        tags:               tags               || [],
        employment_details: { job_type, experience_level, work_mode: work_mode || 'onsite' },
        company_details:    company_details    || {},
      });
    }

    res.status(201).json({ success: true, message: 'Job created successfully', job });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// ── PUT /api/jobs/:id ─────────────────────────────────────────────────────────
exports.updateJob = async (req, res) => {
  try {
    const { id } = req.params;

    const existing = await pool.query('SELECT * FROM jobs WHERE id = $1', [id]);
    if (!existing.rows.length)
      return res.status(404).json({ success: false, message: 'Job not found' });

    if (existing.rows[0].employer_id !== req.user.id && req.user.role !== 'admin')
      return res.status(403).json({ success: false, message: 'Not authorized to update this job' });

    const {
      title, company, location, job_type, salary_min, salary_max,
      experience_level, required_skills, is_active, deadline,
    } = req.body;

    const result = await pool.query(
      `UPDATE jobs SET
         title            = COALESCE($1, title),
         company          = COALESCE($2, company),
         location         = COALESCE($3, location),
         job_type         = COALESCE($4, job_type),
         salary_min       = COALESCE($5, salary_min),
         salary_max       = COALESCE($6, salary_max),
         experience_level = COALESCE($7, experience_level),
         required_skills  = COALESCE($8, required_skills),
         is_active        = COALESCE($9, is_active),
         deadline         = COALESCE($10, deadline)
       WHERE id = $11 RETURNING *`,
      [title, company, location, job_type, salary_min, salary_max,
       experience_level, required_skills, is_active, deadline, id]
    );

    res.json({ success: true, message: 'Job updated', job: result.rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// ── DELETE /api/jobs/:id ──────────────────────────────────────────────────────
exports.deleteJob = async (req, res) => {
  try {
    const { id } = req.params;
    const existing = await pool.query('SELECT employer_id FROM jobs WHERE id = $1', [id]);
    if (!existing.rows.length)
      return res.status(404).json({ success: false, message: 'Job not found' });

    if (existing.rows[0].employer_id !== req.user.id && req.user.role !== 'admin')
      return res.status(403).json({ success: false, message: 'Not authorized' });

    await pool.query('DELETE FROM jobs WHERE id = $1', [id]);
    await JobDescription.deleteOne({ postgres_job_id: Number(id) });
    await JobEmbedding.deleteOne({ postgres_job_id: Number(id) });

    res.json({ success: true, message: 'Job deleted successfully' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// ── GET /api/jobs/employer/my  (employer's own jobs) ─────────────────────────
exports.getMyJobs = async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT j.*, COUNT(a.id) AS application_count
       FROM   jobs j
       LEFT JOIN applications a ON a.job_id = j.id
       WHERE  j.employer_id = $1
       GROUP BY j.id
       ORDER BY j.created_at DESC`,
      [req.user.id]
    );
    res.json({ success: true, jobs: rows });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};
