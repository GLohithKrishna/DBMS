package com.jobportal.service.impl;

import com.jobportal.dto.JobDto;
import com.jobportal.entity.Job;
import com.jobportal.entity.User;
import com.jobportal.exception.BadRequestException;
import com.jobportal.exception.ForbiddenException;
import com.jobportal.exception.ResourceNotFoundException;
import com.jobportal.repository.ApplicationRepository;
import com.jobportal.repository.JobRepository;
import com.jobportal.repository.UserRepository;
import com.jobportal.service.JobService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.List;

@Service
@RequiredArgsConstructor
public class JobServiceImpl implements JobService {

    private final JobRepository jobRepository;
    private final UserRepository userRepository;
    private final ApplicationRepository applicationRepository;

    @Override
    @Transactional
    public JobDto.Response createJob(JobDto.CreateRequest req, String username) {
        User employer = getUser(username);
        if (employer.getRole() == User.Role.APPLICANT) {
            throw new ForbiddenException("Only employers or admins can post jobs.");
        }

        Job job = Job.builder()
                .title(req.getTitle())
                .company(req.getCompany())
                .location(req.getLocation())
                .jobType(req.getJobType())
                .workMode(req.getWorkMode())
                .experienceLevel(req.getExperienceLevel())
                .description(req.getDescription())
                .requirements(req.getRequirements())
                .responsibilities(req.getResponsibilities())
                .skillsRequired(req.getSkillsRequired())
                .salaryMin(req.getSalaryMin())
                .salaryMax(req.getSalaryMax())
                .currency(req.getCurrency() != null ? req.getCurrency() : "INR")
                .deadline(req.getDeadline())
                .category(req.getCategory())
                .openings(req.getOpenings() != null ? req.getOpenings() : 1)
                .status(Job.JobStatus.ACTIVE)
                .postedBy(employer)
                .build();

        return toResponse(jobRepository.save(job));
    }

    @Override
    @Transactional(readOnly = true)
    public JobDto.Response getJobById(Long id) {
        Job job = getJob(id);
        return toResponse(job);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<JobDto.Summary> getAllActiveJobs(Pageable pageable) {
        return jobRepository.findByStatus(Job.JobStatus.ACTIVE, pageable)
                .map(this::toSummary);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<JobDto.Summary> searchJobs(String keyword, Pageable pageable) {
        return jobRepository.searchByKeyword(keyword, pageable).map(this::toSummary);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<JobDto.Summary> filterJobs(String title, String location, String category,
                                           Job.WorkMode workMode, Job.JobType jobType,
                                           Job.ExperienceLevel experienceLevel, Pageable pageable) {
        return jobRepository.findWithFilters(
                        title, location, category, workMode, jobType, experienceLevel, pageable)
                .map(this::toSummary);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<JobDto.Summary> discoverJobsByUserSkills(String username, Pageable pageable) {
        User user = getUser(username);
        if (user.getSkills() == null || user.getSkills().isBlank()) {
            return getAllActiveJobs(pageable);
        }

        String[] skills = Arrays.stream(user.getSkills().split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .toArray(String[]::new);

        String s1 = skills.length > 0 ? skills[0] : null;
        String s2 = skills.length > 1 ? skills[1] : null;
        String s3 = skills.length > 2 ? skills[2] : null;

        return jobRepository.discoverBySkills(s1, s2, s3, pageable).map(this::toSummary);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<JobDto.Summary> getJobsByEmployer(String username, Pageable pageable) {
        User employer = getUser(username);
        return jobRepository.findByPostedById(employer.getId(), pageable).map(this::toSummary);
    }

    @Override
    @Transactional
    public JobDto.Response updateJob(Long id, JobDto.UpdateRequest req, String username) {
        Job job = getJob(id);
        assertOwner(job, username);

        if (req.getTitle() != null)           job.setTitle(req.getTitle());
        if (req.getCompany() != null)         job.setCompany(req.getCompany());
        if (req.getLocation() != null)        job.setLocation(req.getLocation());
        if (req.getJobType() != null)         job.setJobType(req.getJobType());
        if (req.getWorkMode() != null)        job.setWorkMode(req.getWorkMode());
        if (req.getExperienceLevel() != null) job.setExperienceLevel(req.getExperienceLevel());
        if (req.getDescription() != null)     job.setDescription(req.getDescription());
        if (req.getRequirements() != null)    job.setRequirements(req.getRequirements());
        if (req.getResponsibilities() != null)job.setResponsibilities(req.getResponsibilities());
        if (req.getSkillsRequired() != null)  job.setSkillsRequired(req.getSkillsRequired());
        if (req.getSalaryMin() != null)       job.setSalaryMin(req.getSalaryMin());
        if (req.getSalaryMax() != null)       job.setSalaryMax(req.getSalaryMax());
        if (req.getCurrency() != null)        job.setCurrency(req.getCurrency());
        if (req.getDeadline() != null)        job.setDeadline(req.getDeadline());
        if (req.getCategory() != null)        job.setCategory(req.getCategory());
        if (req.getOpenings() != null)        job.setOpenings(req.getOpenings());
        if (req.getStatus() != null)          job.setStatus(req.getStatus());

        return toResponse(jobRepository.save(job));
    }

    @Override
    @Transactional
    public void deleteJob(Long id, String username) {
        Job job = getJob(id);
        assertOwner(job, username);
        jobRepository.delete(job);
    }

    @Override
    @Transactional
    public void closeJob(Long id, String username) {
        Job job = getJob(id);
        assertOwner(job, username);
        job.setStatus(Job.JobStatus.CLOSED);
        jobRepository.save(job);
    }

    @Override
    @Transactional(readOnly = true)
    public List<String> getAllCategories() {
        return jobRepository.findAllCategories();
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private Job getJob(Long id) {
        return jobRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Job not found with id: " + id));
    }

    private User getUser(String username) {
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + username));
    }

    private void assertOwner(Job job, String username) {
        User caller = getUser(username);
        boolean isAdmin = caller.getRole() == User.Role.ADMIN;
        boolean isOwner = job.getPostedBy().getId().equals(caller.getId());
        if (!isOwner && !isAdmin) {
            throw new ForbiddenException("You are not authorized to modify this job.");
        }
    }

    private JobDto.Response toResponse(Job j) {
        long apps = applicationRepository.countByJobId(j.getId());
        return JobDto.Response.builder()
                .id(j.getId())
                .title(j.getTitle())
                .company(j.getCompany())
                .location(j.getLocation())
                .jobType(j.getJobType())
                .workMode(j.getWorkMode())
                .experienceLevel(j.getExperienceLevel())
                .description(j.getDescription())
                .requirements(j.getRequirements())
                .responsibilities(j.getResponsibilities())
                .skillsRequired(j.getSkillsRequired())
                .salaryMin(j.getSalaryMin())
                .salaryMax(j.getSalaryMax())
                .currency(j.getCurrency())
                .deadline(j.getDeadline())
                .status(j.getStatus())
                .category(j.getCategory())
                .openings(j.getOpenings())
                .postedById(j.getPostedBy().getId())
                .postedByUsername(j.getPostedBy().getUsername())
                .totalApplications(apps)
                .createdAt(j.getCreatedAt())
                .updatedAt(j.getUpdatedAt())
                .build();
    }

    private JobDto.Summary toSummary(Job j) {
        return JobDto.Summary.builder()
                .id(j.getId())
                .title(j.getTitle())
                .company(j.getCompany())
                .location(j.getLocation())
                .jobType(j.getJobType())
                .workMode(j.getWorkMode())
                .experienceLevel(j.getExperienceLevel())
                .category(j.getCategory())
                .salaryMin(j.getSalaryMin())
                .salaryMax(j.getSalaryMax())
                .currency(j.getCurrency())
                .status(j.getStatus())
                .createdAt(j.getCreatedAt())
                .build();
    }
}
