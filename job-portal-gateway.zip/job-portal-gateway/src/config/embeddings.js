const axios = require('axios');
require('dotenv').config();

const DIMENSIONS = parseInt(process.env.EMBEDDING_DIMENSIONS || '1536', 10);
const USE_LOCAL_FALLBACK = (process.env.USE_LOCAL_FALLBACK_EMBEDDING || 'true').toLowerCase() === 'true';

/**
 * Generate an embedding vector for the given text.
 * - If EMBEDDING_API_KEY is set, calls the OpenAI-compatible embeddings endpoint.
 * - Otherwise (or on failure), falls back to a deterministic local hash-based
 *   embedding so the system still works fully offline for demos/dev.
 */
async function generateEmbedding(text) {
  const apiKey = process.env.EMBEDDING_API_KEY;
  const baseUrl = process.env.EMBEDDING_BASE_URL || 'https://api.openai.com/v1';
  const model = process.env.EMBEDDING_MODEL || 'text-embedding-3-small';

  if (apiKey && apiKey !== 'your_api_key_here') {
    try {
      const response = await axios.post(
        `${baseUrl}/embeddings`,
        { input: text, model },
        { headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' } }
      );
      return response.data.data[0].embedding;
    } catch (err) {
      console.warn('Embedding API call failed, falling back to local embedding:', err.message);
      if (!USE_LOCAL_FALLBACK) throw err;
    }
  }

  return localHashEmbedding(text);
}

/**
 * Deterministic local "embedding" using a simple hashed bag-of-words approach.
 * Produces a fixed-length vector so it remains compatible with the Mongo
 * vector index dimensions. NOT a real semantic model, but provides
 * reasonable similarity for matching keywords/skills offline.
 */
function localHashEmbedding(text) {
  const vector = new Array(DIMENSIONS).fill(0);
  const words = (text || '')
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter(Boolean);

  for (const word of words) {
    const hash = simpleHash(word);
    const idx = hash % DIMENSIONS;
    vector[idx] += 1;
  }

  // Normalize
  const norm = Math.sqrt(vector.reduce((sum, v) => sum + v * v, 0)) || 1;
  return vector.map((v) => v / norm);
}

function simpleHash(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash);
}

module.exports = { generateEmbedding, DIMENSIONS };
