package com.jobportal.repository;

import com.jobportal.entity.Job;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface JobRepository extends JpaRepository<Job, Long>,
        JpaSpecificationExecutor<Job> {

    Page<Job> findByStatus(Job.JobStatus status, Pageable pageable);

    Page<Job> findByPostedById(Long userId, Pageable pageable);

    Page<Job> findByCategory(String category, Pageable pageable);

    // Full-text keyword search across title, description, company, skills
    @Query("""
            SELECT j FROM Job j
            WHERE j.status = 'ACTIVE'
            AND (
                LOWER(j.title)          LIKE LOWER(CONCAT('%', :keyword, '%')) OR
                LOWER(j.description)    LIKE LOWER(CONCAT('%', :keyword, '%')) OR
                LOWER(j.company)        LIKE LOWER(CONCAT('%', :keyword, '%')) OR
                LOWER(j.skillsRequired) LIKE LOWER(CONCAT('%', :keyword, '%')) OR
                LOWER(j.category)       LIKE LOWER(CONCAT('%', :keyword, '%')) OR
                LOWER(j.location)       LIKE LOWER(CONCAT('%', :keyword, '%'))
            )
            """)
    Page<Job> searchByKeyword(@Param("keyword") String keyword, Pageable pageable);

    // Skill-based discovery
    @Query("""
            SELECT j FROM Job j
            WHERE j.status = 'ACTIVE'
            AND LOWER(j.skillsRequired) LIKE LOWER(CONCAT('%', :skill, '%'))
            """)
    Page<Job> findBySkill(@Param("skill") String skill, Pageable pageable);

    // Experience level filter
    Page<Job> findByExperienceLevelAndStatus(
            Job.ExperienceLevel level, Job.JobStatus status, Pageable pageable);

    // Work mode filter  
    Page<Job> findByWorkModeAndStatus(
            Job.WorkMode mode, Job.JobStatus status, Pageable pageable);

    // Combined filters
    @Query("""
            SELECT j FROM Job j
            WHERE j.status = 'ACTIVE'
            AND (:title       IS NULL OR LOWER(j.title)     LIKE LOWER(CONCAT('%', :title, '%')))
            AND (:location    IS NULL OR LOWER(j.location)  LIKE LOWER(CONCAT('%', :location, '%')))
            AND (:category    IS NULL OR j.category         = :category)
            AND (:workMode    IS NULL OR j.workMode         = :workMode)
            AND (:jobType     IS NULL OR j.jobType          = :jobType)
            AND (:expLevel    IS NULL OR j.experienceLevel  = :expLevel)
            ORDER BY j.createdAt DESC
            """)
    Page<Job> findWithFilters(
            @Param("title")    String title,
            @Param("location") String location,
            @Param("category") String category,
            @Param("workMode") Job.WorkMode workMode,
            @Param("jobType")  Job.JobType jobType,
            @Param("expLevel") Job.ExperienceLevel expLevel,
            Pageable pageable);

    // Discover jobs based on user skills
    @Query("""
            SELECT j FROM Job j
            WHERE j.status = 'ACTIVE'
            AND (
                (:skill1 IS NOT NULL AND LOWER(j.skillsRequired) LIKE LOWER(CONCAT('%', :skill1, '%'))) OR
                (:skill2 IS NOT NULL AND LOWER(j.skillsRequired) LIKE LOWER(CONCAT('%', :skill2, '%'))) OR
                (:skill3 IS NOT NULL AND LOWER(j.skillsRequired) LIKE LOWER(CONCAT('%', :skill3, '%')))
            )
            ORDER BY j.createdAt DESC
            """)
    Page<Job> discoverBySkills(
            @Param("skill1") String skill1,
            @Param("skill2") String skill2,
            @Param("skill3") String skill3,
            Pageable pageable);

    @Query("SELECT DISTINCT j.category FROM Job j WHERE j.category IS NOT NULL")
    List<String> findAllCategories();

    long countByStatus(Job.JobStatus status);
}
