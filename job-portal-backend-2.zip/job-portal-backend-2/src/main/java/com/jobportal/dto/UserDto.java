package com.jobportal.dto;

import com.jobportal.entity.User;
import lombok.*;

import java.time.LocalDateTime;

public class UserDto {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class UpdateRequest {
        private String firstName;
        private String lastName;
        private String phone;
        private String skills;
        private String bio;
        private String resumeUrl;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Response {
        private Long id;
        private String username;
        private String email;
        private String firstName;
        private String lastName;
        private String phone;
        private String skills;
        private String bio;
        private String resumeUrl;
        private User.Role role;
        private boolean enabled;
        private LocalDateTime createdAt;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class ChangePasswordRequest {
        private String currentPassword;
        private String newPassword;
    }
}
