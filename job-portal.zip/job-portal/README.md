# PS-13: Job Listing and Application Interface
## Node.js + PostgreSQL + MongoDB Backend

---

## 📁 Project Structure

```
job-portal/
├── src/
│   ├── server.js                    # Express entry point
│   ├── config/
│   │   ├── postgres.js              # PostgreSQL (pg Pool)
│   │   └── mongodb.js               # Mongoose connection
│   ├── models/
│   │   └── mongoModels.js           # job_descriptions, job_embeddings, application_logs
│   ├── controllers/
│   │   ├── authController.js        # register / login / me
│   │   ├── jobsController.js        # CRUD for jobs
│   │   ├── applicationsController.js# apply / list / status update
│   │   └── searchController.js      # semantic + keyword search
│   ├── routes/
│   │   ├── authRoutes.js
│   │   ├── jobRoutes.js
│   │   ├── applicationRoutes.js
│   │   └── searchRoutes.js
│   └── middleware/
│       └── auth.js                  # JWT authenticate + authorize
├── sql-setup/
│   └── schema.sql                   # PostgreSQL tables + seed data
├── mongodb-setup/
│   ├── seed-mongo.js                # Seeds all 3 Mongo collections
│   └── atlas-vector-index.json      # Vector search index definition
├── .env.example
├── package.json
└── README.md
```

---

## 🚀 Setup

### 1. Install dependencies
```bash
npm install
```

### 2. Configure environment
```bash
cp .env.example .env
# Edit .env with your DB credentials and JWT secret
```

### 3. Set up PostgreSQL
```bash
psql -U postgres -c "CREATE DATABASE job_portal;"
psql -U postgres -d job_portal -f sql-setup/schema.sql
```

### 4. Set up MongoDB
```bash
# Start mongod or use MongoDB Atlas URI in .env
npm run seed:mongo
```

### 5. Start the server
```bash
npm run dev    # development (nodemon)
npm start      # production
```

---

## 📋 API Endpoints

### Auth
| Method | Endpoint             | Access  | Description        |
|--------|----------------------|---------|--------------------|
| POST   | /api/auth/register   | Public  | Register user      |
| POST   | /api/auth/login      | Public  | Login, get JWT     |
| GET    | /api/auth/me         | Auth    | Get current user   |

### Jobs
| Method | Endpoint               | Access           | Description             |
|--------|------------------------|------------------|-------------------------|
| GET    | /api/jobs              | Public           | List all jobs (filters) |
| GET    | /api/jobs/:id          | Public           | Job details             |
| POST   | /api/jobs              | Employer         | Create job              |
| PUT    | /api/jobs/:id          | Employer/Admin   | Update job              |
| DELETE | /api/jobs/:id          | Employer/Admin   | Delete job              |
| GET    | /api/jobs/employer/my  | Employer         | My posted jobs          |

### Applications
| Method | Endpoint                      | Access          | Description             |
|--------|-------------------------------|-----------------|-------------------------|
| POST   | /api/applications             | Jobseeker       | Apply for job           |
| GET    | /api/applications/my          | Jobseeker       | My applications         |
| GET    | /api/applications/job/:job_id | Employer/Admin  | Applicants for a job    |
| PATCH  | /api/applications/:id/status  | Employer/Admin  | Update status           |
| GET    | /api/applications/:id/history | Auth            | Full audit trail (Mongo)|

### Search
| Method | Endpoint                     | Access | Description               |
|--------|------------------------------|--------|---------------------------|
| POST   | /api/search/semantic         | Public | Vector semantic search    |
| GET    | /api/search/keyword?q=       | Public | PostgreSQL full-text      |
| GET    | /api/search/recommendations  | Auth   | Skill-matched jobs        |

---

## 🔍 Semantic Search Example

```json
POST /api/search/semantic
{
  "query": "Software developer jobs for freshers"
}

POST /api/search/semantic
{
  "query": "Remote cloud engineering roles"
}
```

---

## 🗄️ Database Design

### PostgreSQL Tables
- **users** — id, name, email, password(bcrypt), role, skills[], phone, location
- **jobs** — id, employer_id(FK), title, company, location, job_type, salary, experience_level, required_skills[], is_active, deadline
- **applications** — id, job_id(FK), applicant_id(FK), cover_letter, resume_url, status, UNIQUE(job_id, applicant_id)

### MongoDB Collections
- **job_descriptions** — rich text, responsibilities, requirements, benefits, tech_stack, company_details, view counts
- **job_embeddings** — 1536-dim OpenAI vectors for semantic search (Atlas $vectorSearch)
- **application_logs** — full audit trail with status history events array

---

## 🔐 Auth
All protected routes require: `Authorization: Bearer <jwt_token>`

Roles:
- `jobseeker` — browse jobs, apply, track applications
- `employer` — post/manage jobs, review applicants, update status
- `admin` — full access

---

## 📝 Sample Credentials (seeded)
| Role      | Email                    | Password      |
|-----------|--------------------------|---------------|
| employer  | alice@techhire.com       | Password@123  |
| jobseeker | bob@example.com          | Password@123  |
| jobseeker | carol@example.com        | Password@123  |
| employer  | dave@cloudco.com         | Password@123  |
| admin     | admin@jobportal.com      | Password@123  |
