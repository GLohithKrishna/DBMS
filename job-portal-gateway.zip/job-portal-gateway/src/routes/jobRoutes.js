const express = require('express');
const pool = require('../config/db');
const { getDB } = require('../config/mongo');
const { generateEmbedding } = require('../config/embeddings');
const { authMiddleware, optionalAuth } = require('../middleware/auth');

const router = express.Router();

// ------------------------------------------------------------
// GET /api/jobs
// Browse / filter job listings (SQL)
// Query params: location, job_type, experience_level, skill, q (title search)
// ------------------------------------------------------------
router.get('/', async (req, res) => {
  try {
    const { location, job_type, experience_level, skill, q, status } = req.query;

    const conditions = [];
    const values = [];
    let idx = 1;

    if (status) {
      conditions.push(`status = $${idx++}`);
      values.push(status);
    } else {
      conditions.push(`status = $${idx++}`);
      values.push('open');
    }

    if (location) {
      conditions.push(`location ILIKE $${idx++}`);
      values.push(`%${location}%`);
    }
    if (job_type) {
      conditions.push(`job_type ILIKE $${idx++}`);
      values.push(`%${job_type}%`);
    }
    if (experience_level) {
      conditions.push(`experience_level ILIKE $${idx++}`);
      values.push(`%${experience_level}%`);
    }
    if (skill) {
      conditions.push(`skills_required ILIKE $${idx++}`);
      values.push(`%${skill}%`);
    }
    if (q) {
      conditions.push(`(title ILIKE $${idx} OR company ILIKE $${idx})`);
      values.push(`%${q}%`);
      idx++;
    }

    const whereClause = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    const result = await pool.query(
      `SELECT * FROM jobs ${whereClause} ORDER BY created_at DESC`,
      values
    );

    res.json({ count: result.rows.length, jobs: result.rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch jobs' });
  }
});

// ------------------------------------------------------------
// GET /api/jobs/recommendations
// Discover jobs based on logged-in user's skills/interests (SQL)
// ------------------------------------------------------------
router.get('/recommendations', authMiddleware, async (req, res) => {
  try {
    const userResult = await pool.query('SELECT skills, interests FROM users WHERE user_id = $1', [
      req.user.user_id,
    ]);
    if (userResult.rows.length === 0) return res.status(404).json({ error: 'User not found' });

    const { skills, interests } = userResult.rows[0];
    const keywords = [...(skills || '').split(','), ...(interests || '').split(',')]
      .map((s) => s.trim())
      .filter(Boolean);

    if (keywords.length === 0) {
      const result = await pool.query("SELECT * FROM jobs WHERE status = 'open' ORDER BY created_at DESC LIMIT 10");
      return res.json({ count: result.rows.length, jobs: result.rows });
    }

    const conditions = keywords.map((_, i) => `skills_required ILIKE $${i + 1}`).join(' OR ');
    const values = keywords.map((k) => `%${k}%`);

    const result = await pool.query(
      `SELECT * FROM jobs WHERE status = 'open' AND (${conditions}) ORDER BY created_at DESC`,
      values
    );

    res.json({ count: result.rows.length, jobs: result.rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch recommendations' });
  }
});

// ------------------------------------------------------------
// POST /api/jobs/semantic-search
// Vector/semantic search over MongoDB job_embeddings + job_descriptions
// Body: { query: "Software developer jobs for freshers", limit: 10 }
// ------------------------------------------------------------
router.post('/semantic-search', async (req, res) => {
  try {
    const { query, limit } = req.body;
    if (!query) return res.status(400).json({ error: 'query is required' });

    const queryVector = await generateEmbedding(query);
    const db = getDB();

    let results;
    try {
      // MongoDB Atlas Vector Search aggregation pipeline
      results = await db
        .collection('job_embeddings')
        .aggregate([
          {
            $vectorSearch: {
              index: 'job_vector_index',
              path: 'embedding',
              queryVector,
              numCandidates: 100,
              limit: limit || 10,
            },
          },
          {
            $project: {
              job_id: 1,
              title: 1,
              company: 1,
              location: 1,
              skills_required: 1,
              score: { $meta: 'vectorSearchScore' },
            },
          },
        ])
        .toArray();
    } catch (vectorErr) {
      // Fallback: if $vectorSearch index isn't configured (e.g. local MongoDB
      // without Atlas Search), compute cosine similarity in application code.
      console.warn('Falling back to in-app cosine similarity:', vectorErr.message);
      const allDocs = await db.collection('job_embeddings').find({}).toArray();
      results = allDocs
        .map((doc) => ({
          ...doc,
          score: cosineSimilarity(queryVector, doc.embedding),
        }))
        .sort((a, b) => b.score - a.score)
        .slice(0, limit || 10)
        .map(({ embedding, ...rest }) => rest);
    }

    // Enrich with full SQL job details
    const jobIds = results.map((r) => r.job_id);
    let jobDetails = [];
    if (jobIds.length > 0) {
      const sqlResult = await pool.query(
        `SELECT * FROM jobs WHERE job_id = ANY($1::int[]) AND status = 'open'`,
        [jobIds]
      );
      jobDetails = sqlResult.rows;
    }

    const merged = results
      .map((r) => {
        const job = jobDetails.find((j) => j.job_id === r.job_id);
        return job ? { ...job, similarity_score: r.score } : null;
      })
      .filter(Boolean);

    res.json({ query, count: merged.length, results: merged });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Semantic search failed', details: err.message });
  }
});

function cosineSimilarity(a, b) {
  let dot = 0, normA = 0, normB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  if (normA === 0 || normB === 0) return 0;
  return dot / (Math.sqrt(normA) * Math.sqrt(normB));
}

// ------------------------------------------------------------
// GET /api/jobs/:id
// View job details (SQL + MongoDB full description)
// ------------------------------------------------------------
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const sqlResult = await pool.query('SELECT * FROM jobs WHERE job_id = $1', [id]);
    if (sqlResult.rows.length === 0) return res.status(404).json({ error: 'Job not found' });

    const job = sqlResult.rows[0];

    const db = getDB();
    const fullDescription = await db.collection('job_descriptions').findOne({ job_id: parseInt(id, 10) });

    res.json({ ...job, full_description: fullDescription ? fullDescription.description : job.description });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch job details' });
  }
});

// ------------------------------------------------------------
// POST /api/jobs
// Post a new job (recruiter only) - writes to SQL, Mongo job_descriptions,
// and generates a vector embedding into job_embeddings
// ------------------------------------------------------------
router.post('/', authMiddleware, async (req, res) => {
  try {
    if (req.user.role !== 'recruiter' && req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Only recruiters can post jobs' });
    }

    const {
      title,
      company,
      location,
      job_type,
      experience_level,
      salary_min,
      salary_max,
      skills_required,
      description,
      full_description,
    } = req.body;

    if (!title || !company) {
      return res.status(400).json({ error: 'title and company are required' });
    }

    const sqlResult = await pool.query(
      `INSERT INTO jobs (title, company, location, job_type, experience_level, salary_min, salary_max, skills_required, description, posted_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
       RETURNING *`,
      [
        title,
        company,
        location || null,
        job_type || null,
        experience_level || null,
        salary_min || null,
        salary_max || null,
        skills_required || null,
        description || null,
        req.user.user_id,
      ]
    );

    const job = sqlResult.rows[0];
    const db = getDB();

    // Store full description in MongoDB
    await db.collection('job_descriptions').insertOne({
      job_id: job.job_id,
      title,
      company,
      description: full_description || description || '',
      created_at: new Date(),
    });

    // Generate & store embedding for semantic search
    const textForEmbedding = `${title} at ${company}. Location: ${location || ''}. Type: ${job_type || ''}, Level: ${experience_level || ''}. Skills: ${skills_required || ''}. ${full_description || description || ''}`;
    const embedding = await generateEmbedding(textForEmbedding);

    await db.collection('job_embeddings').insertOne({
      job_id: job.job_id,
      title,
      company,
      location,
      skills_required,
      embedding,
      created_at: new Date(),
    });

    res.status(201).json(job);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create job' });
  }
});

module.exports = router;
