// src/controllers/applicationsController.js
const pool               = require('../config/postgres');
const { ApplicationLog } = require('../models/mongoModels');

// ── POST /api/applications  (apply for a job) ────────────────────────────────
exports.applyForJob = async (req, res) => {
  try {
    const { job_id, cover_letter, resume_url } = req.body;
    if (!job_id)
      return res.status(400).json({ success: false, message: 'job_id is required' });

    // Check job exists and is active
    const jobCheck = await pool.query(
      'SELECT id, title, company FROM jobs WHERE id = $1 AND is_active = TRUE', [job_id]
    );
    if (!jobCheck.rows.length)
      return res.status(404).json({ success: false, message: 'Job not found or closed' });

    // Prevent duplicate applications
    const dupCheck = await pool.query(
      'SELECT id FROM applications WHERE job_id = $1 AND applicant_id = $2',
      [job_id, req.user.id]
    );
    if (dupCheck.rows.length)
      return res.status(409).json({ success: false, message: 'You have already applied for this job' });

    // Insert application in PostgreSQL
    const result = await pool.query(
      `INSERT INTO applications (job_id, applicant_id, cover_letter, resume_url)
       VALUES ($1, $2, $3, $4) RETURNING *`,
      [job_id, req.user.id, cover_letter || null, resume_url || null]
    );
    const app = result.rows[0];

    // Create audit log in MongoDB
    const job = jobCheck.rows[0];
    await ApplicationLog.create({
      postgres_application_id: app.id,
      postgres_job_id:         job_id,
      postgres_user_id:        req.user.id,
      applicant_name:          req.user.name,
      job_title:               job.title,
      company:                 job.company,
      events: [{ status: 'pending', changed_by: req.user.id, note: 'Application submitted' }],
      metadata: { ip_address: req.ip, source: 'web' },
    });

    res.status(201).json({ success: true, message: 'Application submitted successfully', application: app });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// ── GET /api/applications/my  (applicant: own applications) ──────────────────
exports.getMyApplications = async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT a.*, j.title AS job_title, j.company, j.location, j.job_type
       FROM   applications a
       JOIN   jobs j ON j.id = a.job_id
       WHERE  a.applicant_id = $1
       ORDER BY a.applied_at DESC`,
      [req.user.id]
    );
    res.json({ success: true, applications: rows });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// ── GET /api/applications/job/:job_id  (employer: applicants for a job) ──────
exports.getJobApplications = async (req, res) => {
  try {
    const { job_id } = req.params;

    // Verify ownership
    const jobCheck = await pool.query(
      'SELECT employer_id FROM jobs WHERE id = $1', [job_id]
    );
    if (!jobCheck.rows.length)
      return res.status(404).json({ success: false, message: 'Job not found' });
    if (jobCheck.rows[0].employer_id !== req.user.id && req.user.role !== 'admin')
      return res.status(403).json({ success: false, message: 'Not authorized' });

    const { rows } = await pool.query(
      `SELECT a.*, u.name AS applicant_name, u.email AS applicant_email,
              u.skills, u.phone, u.location AS applicant_location
       FROM   applications a
       JOIN   users u ON u.id = a.applicant_id
       WHERE  a.job_id = $1
       ORDER BY a.applied_at DESC`,
      [job_id]
    );
    res.json({ success: true, applications: rows });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// ── PATCH /api/applications/:id/status  (update application status) ──────────
exports.updateApplicationStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status, note } = req.body;

    const validStatuses = ['pending', 'reviewed', 'shortlisted', 'rejected', 'hired'];
    if (!validStatuses.includes(status))
      return res.status(400).json({ success: false, message: 'Invalid status value' });

    // Check the application belongs to employer's job
    const appCheck = await pool.query(
      `SELECT a.*, j.employer_id FROM applications a
       JOIN jobs j ON j.id = a.job_id WHERE a.id = $1`,
      [id]
    );
    if (!appCheck.rows.length)
      return res.status(404).json({ success: false, message: 'Application not found' });

    const app = appCheck.rows[0];
    if (app.employer_id !== req.user.id && req.user.role !== 'admin')
      return res.status(403).json({ success: false, message: 'Not authorized' });

    // Update PostgreSQL
    const result = await pool.query(
      'UPDATE applications SET status = $1 WHERE id = $2 RETURNING *',
      [status, id]
    );

    // Append event to MongoDB audit log
    await ApplicationLog.findOneAndUpdate(
      { postgres_application_id: Number(id) },
      {
        $push: {
          events: { status, changed_by: req.user.id, changed_at: new Date(), note: note || '' },
        },
      }
    );

    res.json({ success: true, message: 'Application status updated', application: result.rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// ── GET /api/applications/:id/history  (full audit trail) ────────────────────
exports.getApplicationHistory = async (req, res) => {
  try {
    const { id } = req.params;
    const log = await ApplicationLog.findOne({ postgres_application_id: Number(id) });
    if (!log)
      return res.status(404).json({ success: false, message: 'Application log not found' });

    res.json({ success: true, log });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};
