package com.jobportal.repository;

import com.jobportal.entity.Application;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ApplicationRepository extends JpaRepository<Application, Long> {

    // Applicant views their own applications
    Page<Application> findByApplicantId(Long applicantId, Pageable pageable);

    // Employer views applications for a job
    Page<Application> findByJobId(Long jobId, Pageable pageable);

    // Employer filters by status
    Page<Application> findByJobIdAndStatus(
            Long jobId, Application.ApplicationStatus status, Pageable pageable);

    // Applicant tracks a specific application
    Optional<Application> findByJobIdAndApplicantId(Long jobId, Long applicantId);

    // Check duplicate application
    boolean existsByJobIdAndApplicantId(Long jobId, Long applicantId);

    // Count applications per job
    long countByJobId(Long jobId);

    // Count by status for a job
    long countByJobIdAndStatus(Long jobId, Application.ApplicationStatus status);

    // All applications for jobs posted by an employer
    @Query("""
            SELECT a FROM Application a
            JOIN a.job j
            WHERE j.postedBy.id = :employerId
            ORDER BY a.appliedAt DESC
            """)
    Page<Application> findByEmployerId(@Param("employerId") Long employerId, Pageable pageable);

    // Status count summary for applicant
    @Query("""
            SELECT a.status, COUNT(a) FROM Application a
            WHERE a.applicant.id = :applicantId
            GROUP BY a.status
            """)
    List<Object[]> countByStatusForApplicant(@Param("applicantId") Long applicantId);

    // Recent applications across all jobs (admin view)
    @Query("SELECT a FROM Application a ORDER BY a.appliedAt DESC")
    Page<Application> findAllRecent(Pageable pageable);
}
