-- ============================================================
-- SQL SCHEMA: Job Portal (PostgreSQL)
-- PS-13: Job Listing and Application Interface
-- ============================================================

-- Drop existing tables (in correct dependency order)
DROP TABLE IF EXISTS applications CASCADE;
DROP TABLE IF EXISTS jobs CASCADE;
DROP TABLE IF EXISTS users CASCADE;

-- ============================================================
-- TABLE: users
-- ============================================================
CREATE TABLE users (
    id          SERIAL PRIMARY KEY,
    name        VARCHAR(100)        NOT NULL,
    email       VARCHAR(150)        UNIQUE NOT NULL,
    password    VARCHAR(255)        NOT NULL,
    role        VARCHAR(20)         NOT NULL DEFAULT 'jobseeker'
                                    CHECK (role IN ('jobseeker', 'employer', 'admin')),
    skills      TEXT[],                          -- Array of skills
    resume_url  VARCHAR(500),
    phone       VARCHAR(20),
    location    VARCHAR(100),
    created_at  TIMESTAMP           DEFAULT NOW(),
    updated_at  TIMESTAMP           DEFAULT NOW()
);

-- ============================================================
-- TABLE: jobs
-- ============================================================
CREATE TABLE jobs (
    id              SERIAL PRIMARY KEY,
    employer_id     INTEGER         NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title           VARCHAR(200)    NOT NULL,
    company         VARCHAR(150)    NOT NULL,
    location        VARCHAR(100),
    job_type        VARCHAR(50)     DEFAULT 'full-time'
                                    CHECK (job_type IN ('full-time', 'part-time', 'contract', 'internship', 'remote')),
    salary_min      NUMERIC(12, 2),
    salary_max      NUMERIC(12, 2),
    experience_level VARCHAR(50)    DEFAULT 'entry'
                                    CHECK (experience_level IN ('entry', 'mid', 'senior', 'lead', 'executive')),
    required_skills TEXT[],
    is_active       BOOLEAN         DEFAULT TRUE,
    deadline        DATE,
    created_at      TIMESTAMP       DEFAULT NOW(),
    updated_at      TIMESTAMP       DEFAULT NOW()
);

-- ============================================================
-- TABLE: applications
-- ============================================================
CREATE TABLE applications (
    id              SERIAL PRIMARY KEY,
    job_id          INTEGER         NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
    applicant_id    INTEGER         NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    cover_letter    TEXT,
    resume_url      VARCHAR(500),
    status          VARCHAR(30)     DEFAULT 'pending'
                                    CHECK (status IN ('pending', 'reviewed', 'shortlisted', 'rejected', 'hired')),
    applied_at      TIMESTAMP       DEFAULT NOW(),
    updated_at      TIMESTAMP       DEFAULT NOW(),
    UNIQUE (job_id, applicant_id)   -- Prevent duplicate applications
);

-- ============================================================
-- INDEXES for performance
-- ============================================================
CREATE INDEX idx_jobs_employer      ON jobs(employer_id);
CREATE INDEX idx_jobs_active        ON jobs(is_active);
CREATE INDEX idx_jobs_type          ON jobs(job_type);
CREATE INDEX idx_jobs_skills        ON jobs USING GIN(required_skills);
CREATE INDEX idx_applications_job   ON applications(job_id);
CREATE INDEX idx_applications_user  ON applications(applicant_id);
CREATE INDEX idx_applications_status ON applications(status);
CREATE INDEX idx_users_email        ON users(email);

-- ============================================================
-- TRIGGER: auto-update updated_at on row update
-- ============================================================
CREATE OR REPLACE FUNCTION update_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_users_updated
  BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION update_timestamp();

CREATE TRIGGER trg_jobs_updated
  BEFORE UPDATE ON jobs
  FOR EACH ROW EXECUTE FUNCTION update_timestamp();

CREATE TRIGGER trg_applications_updated
  BEFORE UPDATE ON applications
  FOR EACH ROW EXECUTE FUNCTION update_timestamp();

-- ============================================================
-- SEED DATA
-- ============================================================

-- Users (password = "Password@123" bcrypt hash)
INSERT INTO users (name, email, password, role, skills, location) VALUES
('Alice Recruiter',  'alice@techhire.com',  '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lh2y', 'employer',   NULL,                             'Hyderabad'),
('Bob Dev',          'bob@example.com',     '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lh2y', 'jobseeker',  ARRAY['Node.js','React','MongoDB'], 'Bangalore'),
('Carol Engineer',   'carol@example.com',   '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lh2y', 'jobseeker',  ARRAY['Python','AWS','Docker'],    'Remote'),
('Dave Cloud',       'dave@cloudco.com',    '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lh2y', 'employer',   NULL,                             'Remote'),
('Admin User',       'admin@jobportal.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lh2y', 'admin',      NULL,                             'Hyderabad');

-- Jobs
INSERT INTO jobs (employer_id, title, company, location, job_type, salary_min, salary_max, experience_level, required_skills, deadline) VALUES
(1, 'Full Stack Developer',        'TechHire Inc',   'Hyderabad', 'full-time',  600000,  1200000, 'entry',  ARRAY['Node.js','React','PostgreSQL'],   '2025-03-31'),
(1, 'Backend Engineer',            'TechHire Inc',   'Bangalore', 'full-time',  800000,  1500000, 'mid',    ARRAY['Node.js','MongoDB','REST API'],   '2025-03-15'),
(4, 'Cloud Infrastructure Engineer','CloudCo',       'Remote',    'remote',    1000000, 2000000, 'senior', ARRAY['AWS','Terraform','Docker','K8s'], '2025-04-01'),
(4, 'DevOps Intern',               'CloudCo',        'Remote',    'internship',  80000,   150000, 'entry',  ARRAY['Linux','CI/CD','Docker'],         '2025-02-28'),
(1, 'React Frontend Developer',    'TechHire Inc',   'Hyderabad', 'full-time',  500000,   900000, 'entry',  ARRAY['React','TypeScript','CSS'],       '2025-03-20');

-- Applications
INSERT INTO applications (job_id, applicant_id, cover_letter, status) VALUES
(1, 2, 'I am a passionate full-stack developer eager to contribute.', 'pending'),
(2, 2, 'Backend development is my core expertise with 2 years exp.',  'shortlisted'),
(3, 3, 'Experienced in AWS and Terraform with cloud certifications.',  'reviewed'),
(4, 3, 'Looking for an internship to grow my DevOps skills.',          'rejected'),
(5, 2, 'Frontend is my passion, love building UIs with React.',        'pending');
